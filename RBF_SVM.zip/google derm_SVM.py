import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_XLA_FLAGS"] = "--tf_xla_auto_jit=0"
os.environ["ABSL_LOG_LEVEL"] = "3"


# ============================================================
# 2. IMPORTS
# ============================================================

import joblib
import numpy as np
import pandas as pd

from PIL import Image
from io import BytesIO

import tensorflow as tf

import matplotlib.pyplot as plt

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from sklearn.metrics import (
    classification_report,
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    roc_auc_score,
    recall_score,
    confusion_matrix,
    roc_curve,
    auc
)


# ============================================================
# 3. CLASS DEFINITIONS
# ============================================================

LABEL_MAP = {
    "Acne": 0,
    "Atopy": 1,
    "Normal": 2,
    "Psoriasis": 3,
    "Rosacea": 4,
    "Seborrheic": 5
}

CLASS_NAMES = [
    "Acne",
    "Atopy",
    "Normal",
    "Psoriasis",
    "Rosacea",
    "Seborrheic"
]

NUM_CLASSES = 6


# ============================================================
# 4. OUTPUT DIRECTORY
# ============================================================

OUTPUT_DIR = (
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\derm_foundation_results"
)

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)


# ============================================================
# 5. GOOGLE DERM FOUNDATION MODEL
# ============================================================

MODEL_PATH = (
    r"C:\Users\USER\Desktop\Google\derm-foundation"
)

print("\n==============================================")
print("LOADING GOOGLE DERM FOUNDATION")
print("==============================================")

print("\nModel path:")
print(MODEL_PATH)

if not os.path.exists(MODEL_PATH):

    raise FileNotFoundError(
        "\nGoogle Derm Foundation model directory "
        "was not found:\n"
        + MODEL_PATH
    )

print("\nLoading local TensorFlow SavedModel...")

model = tf.saved_model.load(
    MODEL_PATH
)

print("Model loaded successfully.")


# ============================================================
# 6. CHECK AVAILABLE SIGNATURES
# ============================================================

print("\nAvailable model signatures:")

print(
    list(model.signatures.keys())
)

if "serving_default" not in model.signatures:

    raise RuntimeError(
        "\nThe SavedModel does not contain "
        "'serving_default'.\n\n"
        "Available signatures:\n"
        + str(list(model.signatures.keys()))
    )

infer = model.signatures[
    "serving_default"
]


# ============================================================
# 7. CHECK MODEL INPUT / OUTPUT
# ============================================================

print("\nModel input signature:")

print(
    infer.structured_input_signature
)

print("\nModel output signature:")

print(
    infer.structured_outputs
)


# ============================================================
# 8. TRAINING DIRECTORIES
# ============================================================

train_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Seborrheic side"
]


# ============================================================
# 9. VALIDATION DIRECTORIES
# ============================================================

val_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Seborrheic side"
]


# ============================================================
# 10. CHECK DIRECTORIES
# ============================================================

print("\n==============================================")
print("CHECKING DATA DIRECTORIES")
print("==============================================")

for folder in train_img_dirs:

    if not os.path.isdir(folder):

        raise FileNotFoundError(
            "\nTraining directory not found:\n"
            + folder
        )

for folder in val_img_dirs:

    if not os.path.isdir(folder):

        raise FileNotFoundError(
            "\nValidation directory not found:\n"
            + folder
        )

print("All training directories found.")

print("All validation directories found.")


# ============================================================
# 11. LABEL FUNCTION
# ============================================================

def get_label_from_path(path):

    path_lower = path.lower()

    if "acne" in path_lower:

        return LABEL_MAP["Acne"]

    elif "atopy" in path_lower:

        return LABEL_MAP["Atopy"]

    elif "normal" in path_lower:

        return LABEL_MAP["Normal"]

    elif "psoriasis" in path_lower:

        return LABEL_MAP["Psoriasis"]

    elif "rosacea" in path_lower:

        return LABEL_MAP["Rosacea"]

    elif "seborrheic" in path_lower:

        return LABEL_MAP["Seborrheic"]

    else:

        raise ValueError(
            "\nUnknown class in path:\n"
            + path
        )


# ============================================================
# 12. IMAGE EXTENSIONS
# ============================================================

IMAGE_EXTENSIONS = (
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp"
)


# ============================================================
# 13. GOOGLE DERM FOUNDATION EMBEDDING FUNCTION
# ============================================================

def get_embedding(image_path):

    """
    Convert image to the serialized TensorFlow Example
    format expected by Google Derm Foundation and
    return the embedding vector.
    """

    img = Image.open(
        image_path
    )

    img = img.convert(
        "RGB"
    )

    buffer = BytesIO()

    img.save(
        buffer,
        format="PNG"
    )

    image_bytes = (
        buffer.getvalue()
    )

    example = tf.train.Example(

        features=tf.train.Features(

            feature={

                "image/encoded":
                tf.train.Feature(

                    bytes_list=
                    tf.train.BytesList(

                        value=[
                            image_bytes
                        ]
                    )
                )
            }
        )
    )

    serialized = (
        example.SerializeToString()
    )

    output = infer(
        inputs=tf.constant(
            [serialized]
        )
    )

    if "embedding" not in output:

        raise RuntimeError(
            "\nModel output does not contain "
            "'embedding'.\n\n"
            "Available outputs:\n"
            + str(
                list(output.keys())
            )
        )

    embedding = (
        output["embedding"]
        .numpy()[0]
    )

    return embedding.astype(
        np.float32
    )


# ============================================================
# 14. EXTRACT TRAINING EMBEDDINGS
# ============================================================

print("\n==============================================")
print("EXTRACTING TRAINING EMBEDDINGS")
print("==============================================")

X_train = []
y_train = []

train_failed = 0

for folder in train_img_dirs:

    label = get_label_from_path(
        folder
    )

    print(
        f"\nProcessing: {folder}"
    )

    files = sorted(
        os.listdir(folder)
    )

    image_count = 0

    for file in files:

        if not file.lower().endswith(
            IMAGE_EXTENSIONS
        ):

            continue

        image_path = os.path.join(
            folder,
            file
        )

        try:

            embedding = get_embedding(
                image_path
            )

            X_train.append(
                embedding
            )

            y_train.append(
                label
            )

            image_count += 1

        except Exception as e:

            train_failed += 1

            print(
                "\nFAILED:"
            )

            print(
                image_path
            )

            print(
                str(e)
            )

    print(
        f"Images successfully processed: "
        f"{image_count}"
    )


# ============================================================
# 15. EXTRACT VALIDATION EMBEDDINGS
# ============================================================

print("\n==============================================")
print("EXTRACTING VALIDATION EMBEDDINGS")
print("==============================================")

X_val = []
y_val = []

val_failed = 0

for folder in val_img_dirs:

    label = get_label_from_path(
        folder
    )

    print(
        f"\nProcessing: {folder}"
    )

    files = sorted(
        os.listdir(folder)
    )

    image_count = 0

    for file in files:

        if not file.lower().endswith(
            IMAGE_EXTENSIONS
        ):

            continue

        image_path = os.path.join(
            folder,
            file
        )

        try:

            embedding = get_embedding(
                image_path
            )

            X_val.append(
                embedding
            )

            y_val.append(
                label
            )

            image_count += 1

        except Exception as e:

            val_failed += 1

            print(
                "\nFAILED:"
            )

            print(
                image_path
            )

            print(
                str(e)
            )

    print(
        f"Images successfully processed: "
        f"{image_count}"
    )


# ============================================================
# 16. CONVERT TO NUMPY ARRAYS
# ============================================================

X_train = np.asarray(
    X_train,
    dtype=np.float32
)

y_train = np.asarray(
    y_train,
    dtype=np.int64
)

X_val = np.asarray(
    X_val,
    dtype=np.float32
)

y_val = np.asarray(
    y_val,
    dtype=np.int64
)


# ============================================================
# 17. CHECK DATA
# ============================================================

print("\n==============================================")
print("DATASET SUMMARY")
print("==============================================")

print(
    f"Training samples: "
    f"{len(y_train)}"
)

print(
    f"Validation samples: "
    f"{len(y_val)}"
)

print(
    f"Embedding dimension: "
    f"{X_train.shape[1]}"
)

print(
    f"Training failures: "
    f"{train_failed}"
)

print(
    f"Validation failures: "
    f"{val_failed}"
)

if len(X_train) == 0:

    raise RuntimeError(
        "No training embeddings were generated."
    )

if len(X_val) == 0:

    raise RuntimeError(
        "No validation embeddings were generated."
    )


# ============================================================
# 18. SAVE EMBEDDINGS
# ============================================================

np.save(
    os.path.join(
        OUTPUT_DIR,
        "derm_foundation_X_train.npy"
    ),
    X_train
)

np.save(
    os.path.join(
        OUTPUT_DIR,
        "derm_foundation_y_train.npy"
    ),
    y_train
)

np.save(
    os.path.join(
        OUTPUT_DIR,
        "derm_foundation_X_val.npy"
    ),
    X_val
)

np.save(
    os.path.join(
        OUTPUT_DIR,
        "derm_foundation_y_val.npy"
    ),
    y_val
)

print(
    "\nEmbeddings saved."
)


# ============================================================

# 19. RBF SVM MODEL

# ============================================================

print("\n==============================================")
print("TRAINING RBF SVM")
print("==============================================")

svm = Pipeline(

[
    (
        "scaler",
        StandardScaler()
    ),

    (
        "svm",
        SVC(

            kernel="rbf",

            C=10,

            gamma="scale",

            class_weight="balanced",

            decision_function_shape="ovr",

            probability=True,

            random_state=42
        )
    )
]

)

# ============================================================

# 20. TRAIN RBF SVM

# ============================================================

svm.fit(

X_train,

y_train

)

print(
"\nRBF SVM training completed."
)


# ============================================================

# 22. VALIDATION PREDICTIONS

# ============================================================

print("\n==============================================")
print("GENERATING VALIDATION PREDICTIONS")
print("==============================================")

y_val_pred = svm.predict(

X_val

)

y_val_pred = np.asarray(


y_val_pred,

dtype=np.int64


)

y_val_prob = svm.predict_proba(

X_val

)

y_val_prob = np.asarray(

y_val_prob,

dtype=np.float64

)

# ============================================================
# 23. MAIN METRICS
# ============================================================

accuracy = accuracy_score(
    y_val,
    y_val_pred
)

balanced_accuracy = (
    balanced_accuracy_score(
        y_val,
        y_val_pred
    )
)

macro_f1 = f1_score(
    y_val,
    y_val_pred,
    average="macro"
)

macro_auroc = roc_auc_score(

    y_val,

    y_val_prob,

    multi_class="ovr",

    average="macro",

    labels=np.arange(
        NUM_CLASSES
    )
)


# ============================================================
# 24. PER-CLASS RECALL / SENSITIVITY
# ============================================================

per_class_recall = recall_score(

    y_val,

    y_val_pred,

    labels=np.arange(
        NUM_CLASSES
    ),

    average=None,

    zero_division=0
)


# ============================================================
# 25. PRINT MAIN PERFORMANCE
# ============================================================

print("\n==============================================")
print("GOOGLE DERM FOUNDATION + XGBOOST")
print("VALIDATION PERFORMANCE")
print("==============================================")

print(
    f"\nAccuracy: "
    f"{accuracy:.4f}"
)

print(
    f"Balanced Accuracy: "
    f"{balanced_accuracy:.4f}"
)

print(
    f"Macro-F1: "
    f"{macro_f1:.4f}"
)

print(
    f"Macro-AUROC: "
    f"{macro_auroc:.4f}"
)


# ============================================================
# 26. CLASSIFICATION REPORT
# ============================================================

classification_report_text = (
    classification_report(

        y_val,

        y_val_pred,

        labels=np.arange(
            NUM_CLASSES
        ),

        target_names=CLASS_NAMES,

        digits=4,

        zero_division=0
    )
)

print(
    "\nClassification Report:\n"
)

print(
    classification_report_text
)


# ============================================================
# 27. PER-CLASS SENSITIVITY
# ============================================================

print(
    "\nPer-class sensitivity / recall:"
)

for i, class_name in enumerate(
    CLASS_NAMES
):

    print(

        f"{class_name:15s}: "
        f"{per_class_recall[i]:.4f}"
    )


# ============================================================
# 28. CONFUSION MATRIX
# ============================================================

cm = confusion_matrix(

    y_val,

    y_val_pred,

    labels=np.arange(
        NUM_CLASSES
    )
)

print(
    "\nConfusion Matrix:"
)

print(
    cm
)


# ============================================================
# 29. CONFUSION MATRIX FIGURE
# ============================================================

plt.figure(
    figsize=(8, 7)
)

plt.imshow(
    cm,
    interpolation="nearest"
)

plt.title(
    "Google Derm Foundation + XGBoost "
    "Confusion Matrix"
)

plt.colorbar()

plt.xticks(

    np.arange(NUM_CLASSES),

    CLASS_NAMES,

    rotation=45,

    ha="right"
)

plt.yticks(

    np.arange(NUM_CLASSES),

    CLASS_NAMES
)

plt.xlabel(
    "Predicted label"
)

plt.ylabel(
    "True label"
)


for i in range(
    NUM_CLASSES
):

    for j in range(
        NUM_CLASSES
    ):

        plt.text(

            j,

            i,

            str(cm[i, j]),

            ha="center",

            va="center"
        )


plt.tight_layout()

plt.savefig(

    os.path.join(

        OUTPUT_DIR,

        "derm_foundation_confusion_matrix.png"
    ),

    dpi=300,

    bbox_inches="tight"
)

plt.close()


# ============================================================
# 30. NORMALIZED CONFUSION MATRIX
# ============================================================

cm_normalized = confusion_matrix(

    y_val,

    y_val_pred,

    labels=np.arange(
        NUM_CLASSES
    ),

    normalize="true"
)


plt.figure(
    figsize=(8, 7)
)

plt.imshow(
    cm_normalized,
    interpolation="nearest"
)

plt.title(
    "Google Derm Foundation + XGBoost "
    "Normalized Confusion Matrix"
)

plt.colorbar()

plt.xticks(

    np.arange(NUM_CLASSES),

    CLASS_NAMES,

    rotation=45,

    ha="right"
)

plt.yticks(

    np.arange(NUM_CLASSES),

    CLASS_NAMES
)

plt.xlabel(
    "Predicted label"
)

plt.ylabel(
    "True label"
)


for i in range(
    NUM_CLASSES
):

    for j in range(
        NUM_CLASSES
    ):

        plt.text(

            j,

            i,

            f"{cm_normalized[i, j]:.2f}",

            ha="center",

            va="center"
        )


plt.tight_layout()

plt.savefig(

    os.path.join(

        OUTPUT_DIR,

        "derm_foundation_normalized_confusion_matrix.png"
    ),

    dpi=300,

    bbox_inches="tight"
)

plt.close()


# ============================================================
# 31. MULTICLASS ROC CURVES
# ============================================================

plt.figure(
    figsize=(8, 7)
)

for i, class_name in enumerate(
    CLASS_NAMES
):

    y_true_binary = (
        y_val == i
    ).astype(int)

    fpr, tpr, _ = roc_curve(

        y_true_binary,

        y_val_prob[:, i]
    )

    class_auc = auc(
        fpr,
        tpr
    )

    plt.plot(

        fpr,

        tpr,

        label=(
            f"{class_name} "
            f"(AUC={class_auc:.3f})"
        )
    )


plt.plot(

    [0, 1],

    [0, 1],

    linestyle="--"
)

plt.xlabel(
    "False Positive Rate"
)

plt.ylabel(
    "True Positive Rate"
)

plt.title(
    "Google Derm Foundation + XGBoost "
    "Multiclass ROC"
)

plt.legend(
    loc="lower right"
)

plt.tight_layout()

plt.savefig(

    os.path.join(

        OUTPUT_DIR,

        "derm_foundation_roc_curve.png"
    ),

    dpi=300,

    bbox_inches="tight"
)

plt.close()


# ============================================================
# 32. BOOTSTRAP FUNCTION
# ============================================================

def bootstrap_metric_ci(

    y_true,

    y_pred,

    y_prob,

    metric_function,

    n_bootstrap=2000,

    seed=42

):

    rng = np.random.default_rng(
        seed
    )

    n = len(y_true)

    scores = []

    for _ in range(
        n_bootstrap
    ):

        indices = rng.integers(

            0,

            n,

            size=n
        )

        y_true_boot = (
            y_true[indices]
        )

        y_pred_boot = (
            y_pred[indices]
        )

        y_prob_boot = (
            y_prob[indices]
        )

        try:

            score = metric_function(

                y_true_boot,

                y_pred_boot,

                y_prob_boot
            )

            if np.isfinite(
                score
            ):

                scores.append(
                    score
                )

        except Exception:

            continue


    scores = np.asarray(
        scores,
        dtype=np.float64
    )


    if len(scores) < 100:

        return (
            np.nan,
            np.nan
        )


    lower = np.percentile(
        scores,
        2.5
    )

    upper = np.percentile(
        scores,
        97.5
    )

    return (
        lower,
        upper
    )


# ============================================================
# 33. BOOTSTRAP METRIC FUNCTIONS
# ============================================================

def metric_accuracy(

    y_true,

    y_pred,

    y_prob

):

    return accuracy_score(
        y_true,
        y_pred
    )


def metric_balanced_accuracy(

    y_true,

    y_pred,

    y_prob

):

    return balanced_accuracy_score(
        y_true,
        y_pred
    )


def metric_macro_f1(

    y_true,

    y_pred,

    y_prob

):

    return f1_score(

        y_true,

        y_pred,

        average="macro"
    )


def metric_macro_auroc(

    y_true,

    y_pred,

    y_prob

):

    # A bootstrap sample can occasionally omit one
    # or more classes. AUROC cannot be calculated
    # reliably in that situation.

    if len(
        np.unique(y_true)
    ) < NUM_CLASSES:

        raise ValueError(
            "Not all classes present"
        )

    return roc_auc_score(

        y_true,

        y_prob,

        multi_class="ovr",

        average="macro",

        labels=np.arange(
            NUM_CLASSES
        )
    )


# ============================================================
# 34. BOOTSTRAP CONFIDENCE INTERVALS
# ============================================================

print(
    "\n=============================================="
)

print(
    "BOOTSTRAP 95% CONFIDENCE INTERVALS"
)

print(
    "=============================================="
)

print(
    "\nRunning 2,000 bootstrap iterations..."
)


accuracy_ci = bootstrap_metric_ci(

    y_val,

    y_val_pred,

    y_val_prob,

    metric_accuracy,

    n_bootstrap=2000,

    seed=42
)


balanced_accuracy_ci = (
    bootstrap_metric_ci(

        y_val,

        y_val_pred,

        y_val_prob,

        metric_balanced_accuracy,

        n_bootstrap=2000,

        seed=43
    )
)


macro_f1_ci = bootstrap_metric_ci(

    y_val,

    y_val_pred,

    y_val_prob,

    metric_macro_f1,

    n_bootstrap=2000,

    seed=44
)


macro_auroc_ci = bootstrap_metric_ci(

    y_val,

    y_val_pred,

    y_val_prob,

    metric_macro_auroc,

    n_bootstrap=2000,

    seed=45
)


# ============================================================
# 35. PRINT CONFIDENCE INTERVALS
# ============================================================

print(
    f"\nAccuracy: "
    f"{accuracy:.4f} "
    f"(95% CI "
    f"{accuracy_ci[0]:.4f}–"
    f"{accuracy_ci[1]:.4f})"
)

print(
    f"Balanced Accuracy: "
    f"{balanced_accuracy:.4f} "
    f"(95% CI "
    f"{balanced_accuracy_ci[0]:.4f}–"
    f"{balanced_accuracy_ci[1]:.4f})"
)

print(
    f"Macro-F1: "
    f"{macro_f1:.4f} "
    f"(95% CI "
    f"{macro_f1_ci[0]:.4f}–"
    f"{macro_f1_ci[1]:.4f})"
)

print(
    f"Macro-AUROC: "
    f"{macro_auroc:.4f} "
    f"(95% CI "
    f"{macro_auroc_ci[0]:.4f}–"
    f"{macro_auroc_ci[1]:.4f})"
)


# ============================================================
# 36. PER-CLASS RECALL BOOTSTRAP CIs
# ============================================================

print(
    "\nPer-class sensitivity / recall "
    "with 95% CI:"
)

per_class_ci = []


for class_id, class_name in enumerate(
    CLASS_NAMES
):

    def class_recall_metric(

        y_true,

        y_pred,

        y_prob,

        class_id=class_id

    ):

        y_true_binary = (
            y_true == class_id
        ).astype(int)

        y_pred_binary = (
            y_pred == class_id
        ).astype(int)

        return recall_score(

            y_true_binary,

            y_pred_binary,

            zero_division=0
        )


    ci = bootstrap_metric_ci(

        y_val,

        y_val_pred,

        y_val_prob,

        class_recall_metric,

        n_bootstrap=2000,

        seed=100 + class_id
    )


    per_class_ci.append(
        ci
    )


    print(

        f"{class_name:15s}: "

        f"{per_class_recall[class_id]:.4f} "

        f"(95% CI "

        f"{ci[0]:.4f}–"

        f"{ci[1]:.4f})"
    )


# ============================================================
# 37. SAVE PREDICTIONS
# ============================================================

np.save(

    os.path.join(

        OUTPUT_DIR,

        "derm_foundation_y_val_pred.npy"
    ),

    y_val_pred
)


np.save(

    os.path.join(

        OUTPUT_DIR,

        "derm_foundation_y_val_prob.npy"
    ),

    y_val_prob
)


# ============================================================

# 38. SAVE RBF SVM MODEL

# ============================================================

joblib.dump(

svm,

os.path.join(

    OUTPUT_DIR,

    "derm_foundation_rbf_svm.pkl"
)


)

print(
"\nRBF SVM model saved."
)



# ============================================================
# 39. SAVE PREDICTION CSV
# ============================================================

prediction_df = pd.DataFrame({

    "true_label":
        y_val,

    "true_class":
        [
            CLASS_NAMES[i]
            for i in y_val
        ],

    "predicted_label":
        y_val_pred,

    "predicted_class":
        [
            CLASS_NAMES[i]
            for i in y_val_pred
        ]
})


for i, class_name in enumerate(
    CLASS_NAMES
):

    safe_name = (
        class_name.lower()
        .replace(" ", "_")
    )

    prediction_df[
        f"prob_{safe_name}"
    ] = y_val_prob[:, i]


prediction_df.to_csv(

    os.path.join(

        OUTPUT_DIR,

        "derm_foundation_svm_validation_predictions.csv"
    ),

    index=False
)


# ============================================================
# 40. SAVE RESULTS TEXT FILE
# ============================================================

results_file = os.path.join(

    OUTPUT_DIR,

    "derm_foundation_svm_results.txt"
)


with open(

    results_file,

    "w",

    encoding="utf-8"

) as f:

    f.write(
        "Google Derm Foundation + RBF SVM\n"
    )

    f.write(
        "========================================\n\n"
    )

    f.write(
        f"Embedding dimension: "
        f"{X_train.shape[1]}\n"
    )

    f.write(
        f"Training samples: "
        f"{len(y_train)}\n"
    )

    f.write(
        f"Validation samples: "
        f"{len(y_val)}\n"
    )

    f.write(
        f"Training failures: "
        f"{train_failed}\n"
    )

    f.write(
        f"Validation failures: "
        f"{val_failed}\n\n"
    )


    f.write(
        f"Accuracy: "
        f"{accuracy:.6f}\n"
    )

    f.write(
        f"Accuracy 95% CI: "
        f"{accuracy_ci[0]:.6f} - "
        f"{accuracy_ci[1]:.6f}\n\n"
    )


    f.write(
        f"Balanced Accuracy: "
        f"{balanced_accuracy:.6f}\n"
    )

    f.write(
        f"Balanced Accuracy 95% CI: "
        f"{balanced_accuracy_ci[0]:.6f} - "
        f"{balanced_accuracy_ci[1]:.6f}\n\n"
    )


    f.write(
        f"Macro-F1: "
        f"{macro_f1:.6f}\n"
    )

    f.write(
        f"Macro-F1 95% CI: "
        f"{macro_f1_ci[0]:.6f} - "
        f"{macro_f1_ci[1]:.6f}\n\n"
    )


    f.write(
        f"Macro-AUROC: "
        f"{macro_auroc:.6f}\n"
    )

    f.write(
        f"Macro-AUROC 95% CI: "
        f"{macro_auroc_ci[0]:.6f} - "
        f"{macro_auroc_ci[1]:.6f}\n\n"
    )


    f.write(
        "Per-class sensitivity / recall:\n"
    )


    for i, class_name in enumerate(
        CLASS_NAMES
    ):

        f.write(

            f"{class_name}: "

            f"{per_class_recall[i]:.6f} "

            f"(95% CI "

            f"{per_class_ci[i][0]:.6f} - "

            f"{per_class_ci[i][1]:.6f})\n"
        )


    f.write(
        "\nClassification Report\n"
    )

    f.write(
        "======================\n\n"
    )

    f.write(
        classification_report_text
    )


    f.write(
        "\n\nConfusion Matrix\n"
    )

    f.write(
        "================\n\n"
    )

    f.write(
        np.array2string(cm)
    )


# ============================================================
# 41. FINAL SUMMARY
# ============================================================

print(
    "\n=============================================="
)

print(
    "GOOGLE DERM FOUNDATION + RBF SVM COMPLETE"
)

print(
    "=============================================="
)

print(
    "\nFinal validation performance:"
)

print(
    f"Accuracy          : {accuracy:.4f}"
)

print(
    f"Balanced Accuracy : {balanced_accuracy:.4f}"
)

print(
    f"Macro-F1          : {macro_f1:.4f}"
)

print(
    f"Macro-AUROC       : {macro_auroc:.4f}"
)

print(
    "\nResults saved in:"
)

print(
    OUTPUT_DIR
)

print(
    "\nImportant files:"
)

print(
    "  derm_foundation_X_train.npy"
)

print(
    "  derm_foundation_y_train.npy"
)

print(
    "  derm_foundation_X_val.npy"
)

print(
    "  derm_foundation_y_val.npy"
)

print(
    "  derm_foundation_rbf_svm.pkl"
)
print(
    "  derm_foundation_validation_predictions.csv"
)

print(
    "  derm_foundation_xgboost_learning_curve.png"
)

print(
    "  derm_foundation_confusion_matrix.png"
)

print(
    "  derm_foundation_normalized_confusion_matrix.png"
)

print(
    "  derm_foundation_roc_curve.png"
)

print(
    "\n=============================================="
)

print(
    "DONE"
)

print(
    "=============================================="
)
