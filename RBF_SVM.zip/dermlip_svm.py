
# ============================================================

import os
import sys
import random
import numpy as np
import torch

from PIL import Image

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    roc_auc_score,
    classification_report,
    confusion_matrix,
    roc_curve,
    auc,
)

import joblib
import matplotlib.pyplot as plt


# ============================================================
# 1. Reproducibility
# ============================================================

SEED = 42

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# ============================================================
# 2. Device
# ============================================================

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("Device:", device)

if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))


# ============================================================
# 3. Derm1M source path
# ============================================================

DERM1M_SRC = r"C:\Users\USER\Downloads\Derm1M\src"

if DERM1M_SRC not in sys.path:
    sys.path.insert(0, DERM1M_SRC)

import open_clip


# ============================================================
# 4. Paths
# ============================================================

TRAIN_ROOT = r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data"
VAL_ROOT = r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data"


# ============================================================
# 5. Label mapping
# ============================================================

LABEL_MAP = {
    "Acne": 0,
    "Atopy": 1,
    "Normal": 2,
    "Psoriasis": 3,
    "Rosacea": 4,
    "Seborrheic": 5,
}

CLASS_NAMES = [
    "Acne",
    "Atopy",
    "Normal",
    "Psoriasis",
    "Rosacea",
    "Seborrheic",
]

NUM_CLASSES = 6


# ============================================================
# 6. DermLIP-PanDerm model
# ============================================================

MODEL_NAME = (
    "hf-hub:redlessone/"
    "DermLIP_PanDerm-base-w-PubMed-256"
)

print("\nLoading DermLIP-PanDerm...")

model, _, preprocess = open_clip.create_model_and_transforms(
    MODEL_NAME
)

# Explicitly freeze all model parameters
for param in model.parameters():
    param.requires_grad = False

model = model.to(device)
model.eval()

print("DermLIP-PanDerm loaded.")
print("Model frozen.")
print("Model set to evaluation mode.")


# ============================================================
# 7. Image extensions
# ============================================================

VALID_EXTENSIONS = (
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".tif",
    ".tiff",
)


# ============================================================
# 8. Build image path lists
# ============================================================

def collect_images(root_dir, prefix):

    image_paths = []
    labels = []

    for class_name, class_id in LABEL_MAP.items():

        front_dir = os.path.join(
            root_dir,
            f"{prefix}_{class_name} Front"
        )

        side_dir = os.path.join(
            root_dir,
            f"{prefix}_{class_name} side"
        )

        for folder in [front_dir, side_dir]:

            if not os.path.isdir(folder):
                raise FileNotFoundError(
                    f"Directory not found:\n{folder}"
                )

            filenames = sorted(
                os.listdir(folder)
            )

            for filename in filenames:

                if filename.lower().endswith(
                    VALID_EXTENSIONS
                ):
                    image_paths.append(
                        os.path.join(folder, filename)
                    )
                    labels.append(class_id)

    return image_paths, np.asarray(labels, dtype=np.int64)


train_paths, y_train = collect_images(
    TRAIN_ROOT,
    "TS"
)


val_paths, y_val = collect_images(
    VAL_ROOT,
    "VS"
)

# ============================================================
# 10. DermLIP embedding function
# ============================================================

def get_embedding(image_path):

    image = Image.open(
        image_path
    ).convert("RGB")

    image_tensor = preprocess(
        image
    ).unsqueeze(0).to(device)

    with torch.inference_mode():

        embedding = model.encode_image(
            image_tensor
        )

    # L2 normalization
    embedding = embedding / (
        embedding.norm(
            dim=-1,
            keepdim=True
        ) + 1e-12
    )

    embedding = (
        embedding
        .squeeze(0)
        .cpu()
        .numpy()
    )

    return embedding.astype(
        np.float32
    )


# ============================================================
# 11. Extract training embeddings
# ============================================================

X_train_list = []

for i, image_path in enumerate(train_paths):

    embedding = get_embedding(
        image_path
    )

    X_train_list.append(
        embedding
    )

    if (i + 1) % 100 == 0:
        print(
            f"Training embeddings: "
            f"{i + 1}/{len(train_paths)}"
        )


X_train = np.stack(
    X_train_list
).astype(np.float32)


# ============================================================
# 12. Extract validation embeddings
# ============================================================

X_val_list = []

for i, image_path in enumerate(val_paths):

    embedding = get_embedding(
        image_path
    )

    X_val_list.append(
        embedding
    )

    if (i + 1) % 100 == 0:
        print(
            f"Validation embeddings: "
            f"{i + 1}/{len(val_paths)}"
        )


X_val = np.stack(
    X_val_list
).astype(np.float32)


print("\nTraining RBF SVM...")

svm = Pipeline([
    (
        "scaler",
        StandardScaler()
    ),
    (
        "svm",
        SVC(
            kernel="rbf",
            C=10,
            gamma="scale",
            class_weight="balanced",
            probability=False,
            decision_function_shape="ovr",
            random_state=SEED
        )
    )
])


svm.fit(
    X_train,
    y_train
)


from sklearn.model_selection import learning_curve

train_sizes, train_scores, val_scores = learning_curve(
    svm,
    X_train,
    y_train,
    cv=5,
    scoring="neg_log_loss",
    train_sizes=np.linspace(0.1, 1.0, 10),
    n_jobs=1
)

train_loss = -train_scores.mean(axis=1)
val_loss = -val_scores.mean(axis=1)

np.savetxt(
    "dermlip_svm.dat",
    np.column_stack((train_sizes, train_loss, val_loss)),
    header="train_size train_loss val_loss",
    fmt="%.8f"
)

plt.figure(figsize=(8, 5))

plt.plot(
    train_sizes,
    train_loss,
    marker="o",
    label="Training loss"
)

plt.plot(
    train_sizes,
    val_loss,
    marker="o",
    label="Validation loss"
)

plt.xlabel("Training examples")
plt.ylabel("Log loss")
plt.title("SVM learning curve")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()