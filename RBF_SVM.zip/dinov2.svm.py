# ============================================================
# DINOv2 + RBF SVM DERMATOLOGY CLASSIFICATION
#
# DINOv2 = frozen feature extractor
# RBF SVM = downstream classifier
#
# Classes:
#   Acne
#   Atopy
#   Normal
#   Psoriasis
#   Rosacea
#   Seborrheic
#
# Outputs:
#   Accuracy
#   Balanced Accuracy
#   Macro-F1
#   Per-class sensitivity/recall
#   Macro-AUROC
#   95% bootstrap confidence intervals
#   Confusion matrix
#   Normalized confusion matrix
#   Multiclass ROC curve
#   Saved DINOv2 embeddings
#   Saved RBF SVM model
#   Saved results
# ============================================================


# ============================================================
# 1. IMPORTS
# ============================================================

import os
import random
import numpy as np
import torch
import matplotlib.pyplot as plt

from PIL import Image

from torchvision import transforms

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    recall_score,
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    auc
)

import joblib


# ============================================================
# 2. REPRODUCIBILITY
# ============================================================

SEED = 42

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# ============================================================
# 3. DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("\nUsing device:", device)


# ============================================================
# 4. LOAD DINOV2
# ============================================================

print("\n==========================================")
print("LOADING DINOv2")
print("==========================================")

print(
    "\nDownloading/loading DINOv2 weights..."
)

# DINOv2 ViT-B/14
# Expected embedding dimension = 768

dinov2 = torch.hub.load(
    "facebookresearch/dinov2",
    "dinov2_vitb14"
)


# Explicitly freeze DINOv2

for param in dinov2.parameters():

    param.requires_grad = False


dinov2 = dinov2.to(device)

dinov2.eval()


print(
    "\nDINOv2 loaded successfully."
)

print(
    "DINOv2 model: ViT-B/14"
)

print(
    "Expected embedding dimension: 768"
)


# ============================================================
# 5. DINOv2 PREPROCESSING
# ============================================================

transform = transforms.Compose([

    transforms.Resize(
        256,
        interpolation=transforms.InterpolationMode.BICUBIC
    ),

    transforms.CenterCrop(224),

    transforms.ToTensor(),

    transforms.Normalize(
        mean=[
            0.485,
            0.456,
            0.406
        ],
        std=[
            0.229,
            0.224,
            0.225
        ]
    )
])


# ============================================================
# 6. LABEL MAP
# ============================================================

LABEL_MAP = {

    "Acne": 0,

    "Atopy": 1,

    "Normal": 2,

    "Psoriasis": 3,

    "Rosacea": 4,

    "Seborrheic": 5
}


CLASS_NAMES = [

    "Acne",

    "Atopy",

    "Normal",

    "Psoriasis",

    "Rosacea",

    "Seborrheic"
]


NUM_CLASSES = len(
    CLASS_NAMES
)


# ============================================================
# 7. LABEL FUNCTION
# ============================================================

def get_label_from_path(folder_path):

    folder_name = os.path.basename(
        os.path.normpath(folder_path)
    ).lower()

    for disease_name, label in LABEL_MAP.items():

        if disease_name.lower() in folder_name:

            return label

    raise ValueError(
        f"Could not determine label from folder:\n"
        f"{folder_path}"
    )


# ============================================================
# 8. TRAINING DIRECTORIES
# ============================================================

train_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Seborrheic side"
]


# ============================================================
# 9. VALIDATION DIRECTORIES
# ============================================================

val_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Seborrheic side"
]


# ============================================================
# 10. IMAGE EMBEDDING FUNCTION
# ============================================================

def get_embedding(image_path):

    image = Image.open(
        image_path
    ).convert("RGB")

    image_tensor = transform(
        image
    ).unsqueeze(0)

    image_tensor = image_tensor.to(
        device
    )

    with torch.inference_mode():

        embedding = dinov2(
            image_tensor
        )

    embedding = embedding.squeeze(
        0
    ).cpu().numpy()

    return embedding.astype(
        np.float32
    )


# ============================================================
# 11. EXTRACT DATASET EMBEDDINGS
# ============================================================

def extract_dataset_embeddings(
    directories,
    dataset_name
):

    X = []

    y = []

    valid_extensions = (

        ".jpg",

        ".jpeg",

        ".png",

        ".bmp"
    )

    print(
        "\n=========================================="
    )

    print(
        f"STARTING {dataset_name.upper()} "
        "DINOv2 FEATURE EXTRACTION"
    )

    print(
        "=========================================="
    )


    for folder in directories:

        if not os.path.isdir(folder):

            print(
                f"\nWARNING: Folder does not exist:\n"
                f"{folder}"
            )

            continue


        label = get_label_from_path(
            folder
        )


        files = [

            file

            for file in os.listdir(folder)

            if file.lower().endswith(
                valid_extensions
            )
        ]

        # Keep file ordering deterministic

        files = sorted(files)


        print(
            f"\nProcessing: "
            f"{os.path.basename(folder)}"
        )

        print(
            f"Label: {label}"
        )

        print(
            f"Images: {len(files)}"
        )


        for i, file in enumerate(
            files,
            start=1
        ):

            image_path = os.path.join(
                folder,
                file
            )


            try:

                embedding = get_embedding(
                    image_path
                )

                X.append(
                    embedding
                )

                y.append(
                    label
                )


            except Exception as e:

                print(
                    f"\nERROR: {image_path}"
                )

                print(e)


            if i % 50 == 0:

                print(
                    f"  Processed "
                    f"{i}/{len(files)}"
                )


    X = np.asarray(
        X,
        dtype=np.float32
    )


    y = np.asarray(
        y,
        dtype=np.int64
    )


    print(
        "\n------------------------------------------"
    )

    print(
        f"{dataset_name} extraction complete"
    )

    print(
        "X shape:",
        X.shape
    )

    print(
        "y shape:",
        y.shape
    )


    return X, y


# ============================================================
# 12. EXTRACT TRAINING FEATURES
# ============================================================

X_train, y_train = extract_dataset_embeddings(

    train_img_dirs,

    "Training"
)


# ============================================================
# 13. EXTRACT VALIDATION FEATURES
# ============================================================

X_val, y_val = extract_dataset_embeddings(

    val_img_dirs,

    "Validation"
)


# ============================================================
# 14. CHECK EMBEDDINGS
# ============================================================

print(
    "\n=========================================="
)

print(
    "DINOv2 EMBEDDING DIMENSION CHECK"
)

print(
    "=========================================="
)


print(
    "Training embedding shape:",
    X_train.shape
)

print(
    "Validation embedding shape:",
    X_val.shape
)


if len(X_train) == 0:

    raise ValueError(
        "No training embeddings were extracted."
    )


if len(X_val) == 0:

    raise ValueError(
        "No validation embeddings were extracted."
    )


print(
    "DINOv2 embedding dimension:",
    X_train.shape[1]
)


if X_train.shape[1] != 768:

    print(
        "\nWARNING:"
        "\nExpected DINOv2 ViT-B/14 embedding "
        "dimension = 768."
        f"\nActual dimension = {X_train.shape[1]}"
    )


# ============================================================
# 15. CLASS DISTRIBUTION
# ============================================================

print(
    "\n=========================================="
)

print(
    "TRAINING CLASS DISTRIBUTION"
)

print(
    "=========================================="
)


for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_train == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )


print(
    "\n=========================================="
)

print(
    "VALIDATION CLASS DISTRIBUTION"
)

print(
    "=========================================="
)


for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_val == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )


# ============================================================
# 16. RBF SVM
# ============================================================

print(
    "\n=========================================="
)

print(
    "TRAINING DINOv2 + RBF SVM"
)

print(
    "=========================================="
)


print(
    "\nSVM configuration:"
)

print(
    "  Kernel: RBF"
)

print(
    "  C: 10"
)

print(
    "  Gamma: scale"
)

print(
    "  Class weight: balanced"
)

print(
    "  Probability: True"
)


svm = Pipeline([

    (
        "scaler",
        StandardScaler()
    ),

    (
        "svm",
        SVC(

            kernel="rbf",

            C=10,

            gamma="scale",

            class_weight="balanced",

            probability=True,

            decision_function_shape="ovr",

            random_state=SEED
        )
    )
])


print(
    "\nFitting SVM..."
)


svm.fit(

    X_train,

    y_train
)


print(
    "\nDINOv2 + RBF SVM training completed."
)


# ============================================================
# 17. VALIDATION PREDICTIONS
# ============================================================

print(
    "\n=========================================="
)

print(
    "GENERATING VALIDATION PREDICTIONS"
)

print(
    "=========================================="
)


y_val_pred = svm.predict(
    X_val
)


# Probability estimates are required for
# multiclass AUROC.

y_val_prob = svm.predict_proba(
    X_val
)


print(
    "\nProbability shape:",
    y_val_prob.shape
)


print(
    "First probability vector:",
    y_val_prob[0]
)


print(
    "First probability sum:",
    y_val_prob[0].sum()
)


# ============================================================
# 18. BASIC METRICS
# ============================================================

accuracy = accuracy_score(

    y_val,

    y_val_pred
)


balanced_accuracy = balanced_accuracy_score(

    y_val,

    y_val_pred
)


macro_f1 = f1_score(

    y_val,

    y_val_pred,

    average="macro"
)


macro_auroc = roc_auc_score(

    y_val,

    y_val_prob,

    multi_class="ovr",

    average="macro",

    labels=np.arange(
        NUM_CLASSES
    )
)


# ============================================================
# 19. PER-CLASS RECALL
# ============================================================

per_class_recall = recall_score(

    y_val,

    y_val_pred,

    labels=np.arange(
        NUM_CLASSES
    ),

    average=None,

    zero_division=0
)


# ============================================================
# 20. PRINT RESULTS
# ============================================================

print(
    "\n=============================================="
)

print(
    "DINOv2 + RBF SVM VALIDATION PERFORMANCE"
)

print(
    "=============================================="
)


print(
    f"\nAccuracy:              {accuracy:.4f}"
)


print(
    f"Balanced Accuracy:     "
    f"{balanced_accuracy:.4f}"
)


print(
    f"Macro-F1:              {macro_f1:.4f}"
)


print(
    f"Macro-AUROC:           {macro_auroc:.4f}"
)


# ============================================================
# 21. CLASSIFICATION REPORT
# ============================================================

print(
    "\nClassification Report:\n"
)


classification_report_text = classification_report(

    y_val,

    y_val_pred,

    labels=np.arange(
        NUM_CLASSES
    ),

    target_names=CLASS_NAMES,

    digits=4,

    zero_division=0
)


print(
    classification_report_text
)


# ============================================================
# 22. PER-CLASS SENSITIVITY
# ============================================================

print(
    "\nPer-class sensitivity / recall:"
)


for i, class_name in enumerate(
    CLASS_NAMES
):

    print(

        f"{class_name:15s}: "
        f"{per_class_recall[i]:.4f}"
    )


# ============================================================
# 23. CONFUSION MATRIX
# ============================================================

cm = confusion_matrix(

    y_val,

    y_val_pred,

    labels=np.arange(
        NUM_CLASSES
    )
)


print(
    "\nConfusion Matrix:"
)


print(cm)


# ============================================================
# 24. CONFUSION MATRIX FIGURE
# ============================================================

plt.figure(
    figsize=(8, 7)
)


plt.imshow(
    cm,
    interpolation="nearest"
)


plt.title(
    "DINOv2 + RBF SVM Confusion Matrix"
)


plt.colorbar()


plt.xticks(

    np.arange(
        NUM_CLASSES
    ),

    CLASS_NAMES,

    rotation=45,

    ha="right"
)


plt.yticks(

    np.arange(
        NUM_CLASSES
    ),

    CLASS_NAMES
)


plt.xlabel(
    "Predicted label"
)


plt.ylabel(
    "True label"
)


for i in range(NUM_CLASSES):

    for j in range(NUM_CLASSES):

        plt.text(

            j,

            i,

            cm[i, j],

            ha="center",

            va="center"
        )


plt.tight_layout()


plt.savefig(

    "dinov2_svm_confusion_matrix.png",

    dpi=300,

    bbox_inches="tight"
)


plt.show()


# ============================================================
# 25. NORMALIZED CONFUSION MATRIX
# ============================================================

cm_normalized = confusion_matrix(

    y_val,

    y_val_pred,

    labels=np.arange(
        NUM_CLASSES
    ),

    normalize="true"
)


plt.figure(
    figsize=(8, 7)
)


plt.imshow(

    cm_normalized,

    interpolation="nearest"
)


plt.title(

    "DINOv2 + RBF SVM "
    "Normalized Confusion Matrix"
)


plt.colorbar()


plt.xticks(

    np.arange(
        NUM_CLASSES
    ),

    CLASS_NAMES,

    rotation=45,

    ha="right"
)


plt.yticks(

    np.arange(
        NUM_CLASSES
    ),

    CLASS_NAMES
)


plt.xlabel(
    "Predicted label"
)


plt.ylabel(
    "True label"
)


for i in range(NUM_CLASSES):

    for j in range(NUM_CLASSES):

        plt.text(

            j,

            i,

            f"{cm_normalized[i, j]:.2f}",

            ha="center",

            va="center"
        )


plt.tight_layout()


plt.savefig(

    "dinov2_svm_normalized_confusion_matrix.png",

    dpi=300,

    bbox_inches="tight"
)


plt.show()


# ============================================================
# 26. MULTICLASS ROC CURVE
# ============================================================

plt.figure(
    figsize=(8, 7)
)


for i, class_name in enumerate(
    CLASS_NAMES
):

    y_true_binary = (

        y_val == i

    ).astype(int)


    fpr, tpr, _ = roc_curve(

        y_true_binary,

        y_val_prob[:, i]
    )


    class_auc = auc(

        fpr,

        tpr
    )


    plt.plot(

        fpr,

        tpr,

        label=f"{class_name} "
              f"(AUC={class_auc:.3f})"
    )


plt.plot(

    [0, 1],

    [0, 1],

    linestyle="--"
)


plt.xlabel(
    "False Positive Rate"
)


plt.ylabel(
    "True Positive Rate"
)


plt.title(
    "DINOv2 + RBF SVM Multiclass ROC"
)


plt.legend(
    loc="lower right"
)


plt.tight_layout()


plt.savefig(

    "dinov2_svm_roc_curve.png",

    dpi=300,

    bbox_inches="tight"
)


plt.show()


# ============================================================
# 27. BOOTSTRAP 95% CI
# ============================================================

def bootstrap_metric_ci(

    y_true,

    y_pred,

    y_prob,

    metric_function,

    n_bootstrap=2000,

    seed=42

):

    rng = np.random.default_rng(
        seed
    )


    n = len(y_true)


    scores = []


    for _ in range(
        n_bootstrap
    ):

        indices = rng.integers(

            0,

            n,

            n
        )


        y_true_boot = (

            y_true[indices]
        )


        y_pred_boot = (

            y_pred[indices]
        )


        y_prob_boot = (

            y_prob[indices]
        )


        try:

            score = metric_function(

                y_true_boot,

                y_pred_boot,

                y_prob_boot
            )


            if np.isfinite(score):

                scores.append(
                    score
                )


        except Exception:

            continue


    scores = np.asarray(
        scores
    )


    if len(scores) < 100:

        raise RuntimeError(

            "Too few valid bootstrap "
            "samples for confidence interval."
        )


    lower = np.percentile(

        scores,

        2.5
    )


    upper = np.percentile(

        scores,

        97.5
    )


    return lower, upper


# ============================================================
# 28. METRIC FUNCTIONS
# ============================================================

def metric_accuracy(

    y_true,

    y_pred,

    y_prob

):

    return accuracy_score(

        y_true,

        y_pred
    )


def metric_balanced_accuracy(

    y_true,

    y_pred,

    y_prob

):

    return balanced_accuracy_score(

        y_true,

        y_pred
    )


def metric_macro_f1(

    y_true,

    y_pred,

    y_prob

):

    return f1_score(

        y_true,

        y_pred,

        average="macro"
    )


def metric_macro_auroc(

    y_true,

    y_pred,

    y_prob

):

    return roc_auc_score(

        y_true,

        y_prob,

        multi_class="ovr",

        average="macro",

        labels=np.arange(
            NUM_CLASSES
        )
    )


# ============================================================
# 29. BOOTSTRAP CIs
# ============================================================

print(
    "\n=============================================="
)

print(
    "BOOTSTRAP 95% CONFIDENCE INTERVALS"
)

print(
    "=============================================="
)


print(
    "\nRunning 2,000 bootstrap iterations..."
)


accuracy_ci = bootstrap_metric_ci(

    y_val,

    y_val_pred,

    y_val_prob,

    metric_accuracy,

    n_bootstrap=2000,

    seed=42
)


balanced_accuracy_ci = bootstrap_metric_ci(

    y_val,

    y_val_pred,

    y_val_prob,

    metric_balanced_accuracy,

    n_bootstrap=2000,

    seed=43
)


macro_f1_ci = bootstrap_metric_ci(

    y_val,

    y_val_pred,

    y_val_prob,

    metric_macro_f1,

    n_bootstrap=2000,

    seed=44
)


macro_auroc_ci = bootstrap_metric_ci(

    y_val,

    y_val_pred,

    y_val_prob,

    metric_macro_auroc,

    n_bootstrap=2000,

    seed=45
)


# ============================================================
# 30. PRINT CIs
# ============================================================

print(

    f"\nAccuracy: "
    f"{accuracy:.4f} "
    f"(95% CI "
    f"{accuracy_ci[0]:.4f}–"
    f"{accuracy_ci[1]:.4f})"
)


print(

    f"Balanced Accuracy: "
    f"{balanced_accuracy:.4f} "
    f"(95% CI "
    f"{balanced_accuracy_ci[0]:.4f}–"
    f"{balanced_accuracy_ci[1]:.4f})"
)


print(

    f"Macro-F1: "
    f"{macro_f1:.4f} "
    f"(95% CI "
    f"{macro_f1_ci[0]:.4f}–"
    f"{macro_f1_ci[1]:.4f})"
)


print(

    f"Macro-AUROC: "
    f"{macro_auroc:.4f} "
    f"(95% CI "
    f"{macro_auroc_ci[0]:.4f}–"
    f"{macro_auroc_ci[1]:.4f})"
)


# ============================================================
# 31. PER-CLASS RECALL CI
# ============================================================

print(

    "\nPer-class sensitivity / recall "
    "with 95% CI:"
)


per_class_recall_ci = {}


for class_id, class_name in enumerate(
    CLASS_NAMES
):


    def class_recall_metric(

        y_true,

        y_pred,

        y_prob,

        class_id=class_id

    ):

        y_true_binary = (

            y_true == class_id
        ).astype(int)


        y_pred_binary = (

            y_pred == class_id
        ).astype(int)


        return recall_score(

            y_true_binary,

            y_pred_binary,

            zero_division=0
        )


    ci = bootstrap_metric_ci(

        y_val,

        y_val_pred,

        y_val_prob,

        class_recall_metric,

        n_bootstrap=2000,

        seed=100 + class_id
    )


    per_class_recall_ci[class_id] = ci


    print(

        f"{class_name:15s}: "
        f"{per_class_recall[class_id]:.4f} "
        f"(95% CI "
        f"{ci[0]:.4f}–"
        f"{ci[1]:.4f})"
    )


# ============================================================
# 32. SAVE EMBEDDINGS
# ============================================================

np.save(

    "dinov2_X_train.npy",

    X_train
)


np.save(

    "dinov2_y_train.npy",

    y_train
)


np.save(

    "dinov2_X_val.npy",

    X_val
)


np.save(

    "dinov2_y_val.npy",

    y_val
)


# ============================================================
# 33. SAVE RBF SVM MODEL
# ============================================================

joblib.dump(

    svm,

    "dinov2_rbf_svm.joblib"
)


# ============================================================
# 34. SAVE RESULTS
# ============================================================

with open(

    "dinov2_svm_results.txt",

    "w"

) as f:


    f.write(

        "DINOv2 + RBF SVM "
        "Validation Results\n"
    )


    f.write(

        "====================================\n\n"
    )


    f.write(

        "Feature extractor: DINOv2 ViT-B/14\n"
    )


    f.write(

        f"Embedding dimension: "
        f"{X_train.shape[1]}\n\n"
    )


    f.write(

        "Downstream classifier: RBF SVM\n"
    )


    f.write(

        "Kernel: RBF\n"
    )


    f.write(

        "C: 10\n"
    )


    f.write(

        "Gamma: scale\n"
    )


    f.write(

        "Class weight: balanced\n"
    )


    f.write(

        "Probability estimates: True\n\n"
    )


    f.write(

        f"Accuracy: "
        f"{accuracy:.6f}\n"
    )


    f.write(

        f"Accuracy 95% CI: "
        f"{accuracy_ci[0]:.6f} - "
        f"{accuracy_ci[1]:.6f}\n\n"
    )


    f.write(

        f"Balanced Accuracy: "
        f"{balanced_accuracy:.6f}\n"
    )


    f.write(

        f"Balanced Accuracy 95% CI: "
        f"{balanced_accuracy_ci[0]:.6f} - "
        f"{balanced_accuracy_ci[1]:.6f}\n\n"
    )


    f.write(

        f"Macro-F1: "
        f"{macro_f1:.6f}\n"
    )


    f.write(

        f"Macro-F1 95% CI: "
        f"{macro_f1_ci[0]:.6f} - "
        f"{macro_f1_ci[1]:.6f}\n\n"
    )


    f.write(

        f"Macro-AUROC: "
        f"{macro_auroc:.6f}\n"
    )


    f.write(

        f"Macro-AUROC 95% CI: "
        f"{macro_auroc_ci[0]:.6f} - "
        f"{macro_auroc_ci[1]:.6f}\n\n"
    )


    f.write(
        "Per-class sensitivity / recall:\n"
    )


    for i, class_name in enumerate(
        CLASS_NAMES
    ):

        ci = per_class_recall_ci[i]


        f.write(

            f"{class_name}: "
            f"{per_class_recall[i]:.6f} "
            f"(95% CI "
            f"{ci[0]:.6f} - "
            f"{ci[1]:.6f})\n"
        )


    f.write(
        "\nClassification Report:\n"
    )


    f.write(
        classification_report_text
    )


    f.write(
        "\nConfusion Matrix:\n"
    )


    f.write(
        np.array2string(cm)
    )


# ============================================================
# 35. COMPLETE
# ============================================================

print(
    "\n=============================================="
)


print(
    "DINOv2 + RBF SVM COMPLETE"
)


print(
    "=============================================="
)


print(
    "\nFiles saved:"
)


print(
    "  dinov2_X_train.npy"
)


print(
    "  dinov2_y_train.npy"
)


print(
    "  dinov2_X_val.npy"
)


print(
    "  dinov2_y_val.npy"
)


print(
    "  dinov2_rbf_svm.joblib"
)


print(
    "  dinov2_svm_results.txt"
)


print(
    "  dinov2_svm_confusion_matrix.png"
)


print(
    "  dinov2_svm_normalized_confusion_matrix.png"
)


print(
    "  dinov2_svm_roc_curve.png"
)