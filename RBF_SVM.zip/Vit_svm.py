

# ============================================================
# 1. IMPORTS
# ============================================================

import os
import random
import numpy as np
import torch
import matplotlib.pyplot as plt
import joblib

from PIL import Image

from transformers import ViTImageProcessor, ViTModel

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    recall_score,
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    auc
)


# ============================================================
# 2. REPRODUCIBILITY
# ============================================================

SEED = 42

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# ============================================================
# 3. DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("Device:", device)


# ============================================================
# 4. LABEL MAP
# ============================================================

LABEL_MAP = {
    "Acne": 0,
    "Atopy": 1,
    "Normal": 2,
    "Psoriasis": 3,
    "Rosacea": 4,
    "Seborrheic": 5
}

CLASS_NAMES = [
    "Acne",
    "Atopy",
    "Normal",
    "Psoriasis",
    "Rosacea",
    "Seborrheic"
]

NUM_CLASSES = 6


# ============================================================
# 5. MODEL
# ============================================================

MODEL_NAME = "google/vit-base-patch16-224-in21k"

print("\n==============================================")
print("LOADING PRETRAINED ViT")
print("==============================================")

processor = ViTImageProcessor.from_pretrained(
    MODEL_NAME
)

model = ViTModel.from_pretrained(
    MODEL_NAME
)


# ============================================================
# FREEZE ViT
# ============================================================

for param in model.parameters():
    param.requires_grad = False

model = model.to(device)

model.eval()

print("ViT loaded successfully.")
print("Model:", MODEL_NAME)
print("All ViT parameters frozen.")


# ============================================================
# 6. LABEL FUNCTION
# ============================================================

def get_label_from_path(folder_path):

    folder_name = os.path.basename(
        os.path.normpath(folder_path)
    ).lower()

    for disease_name, label in LABEL_MAP.items():

        if disease_name.lower() in folder_name:
            return label

    raise ValueError(
        f"Could not determine label from folder: "
        f"{folder_path}"
    )


# ============================================================
# 7. TRAINING IMAGE DIRECTORIES
# ============================================================


# ============================================================
# 8. TRAINING DIRECTORIES
# ============================================================

train_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Seborrheic side"
]


# ============================================================
# 9. VALIDATION DIRECTORIES
# ============================================================

val_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Seborrheic side"
]


# ============================================================
# 9. VALID IMAGE EXTENSIONS
# ============================================================

valid_extensions = (
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp"
)


# ============================================================
# 10. IMAGE → ViT EMBEDDING
# ============================================================

def get_embedding(image_path):

    image = Image.open(
        image_path
    ).convert("RGB")

    inputs = processor(
        images=image,
        return_tensors="pt"
    )

    # Move inputs to GPU if available
    inputs = {
        key: value.to(device)
        for key, value in inputs.items()
    }

    with torch.no_grad():

        outputs = model(
            **inputs
        )

    # CLS token
    embedding = outputs.last_hidden_state[
        :, 0, :
    ]

    return embedding.squeeze(0).cpu().numpy()


# ============================================================
# 11. EXTRACT TRAINING EMBEDDINGS
# ============================================================

print("\n==============================================")
print("STARTING ViT TRAINING FEATURE EXTRACTION")
print("==============================================")


X_train = []
y_train = []


for folder in train_img_dirs:

    if not os.path.isdir(folder):

        print(
            f"WARNING: Folder does not exist:\n{folder}"
        )

        continue

    label = get_label_from_path(folder)

    print(
        f"\nProcessing: "
        f"{os.path.basename(folder)}"
    )

    print(
        f"Label: {label}"
    )

    files = sorted([
        file
        for file in os.listdir(folder)
        if file.lower().endswith(valid_extensions)
    ])

    print(
        f"Images: {len(files)}"
    )

    for i, file in enumerate(
        files,
        start=1
    ):

        image_path = os.path.join(
            folder,
            file
        )

        try:

            emb = get_embedding(
                image_path
            )

            X_train.append(
                emb
            )

            y_train.append(
                label
            )

        except Exception as e:

            print(
                f"ERROR: {image_path}"
            )

            print(e)

        if i % 50 == 0:

            print(
                f"  Processed "
                f"{i}/{len(files)}"
            )


# ============================================================
# 12. CONVERT TRAINING DATA TO NUMPY
# ============================================================

X_train = np.asarray(
    X_train,
    dtype=np.float32
)

y_train = np.asarray(
    y_train,
    dtype=np.int64
)


print("\n==============================================")
print("ViT TRAINING FEATURE EXTRACTION COMPLETE")
print("==============================================")

print(
    "X_train shape:",
    X_train.shape
)

print(
    "y_train shape:",
    y_train.shape
)


# ============================================================
# 13. CHECK EMBEDDING DIMENSION
# ============================================================

if len(X_train) > 0:

    print(
        "Embedding dimension:",
        X_train.shape[1]
    )

    if X_train.shape[1] != 768:

        raise ValueError(
            f"Expected 768-dimensional "
            f"ViT embeddings, "
            f"but got {X_train.shape[1]}"
        )


# ============================================================
# 14. TRAINING CLASS DISTRIBUTION
# ============================================================

print("\nClass distribution:")

for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_train == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )


# ============================================================
# 15. EXTRACT VALIDATION EMBEDDINGS
# ============================================================

print("\n==============================================")
print("STARTING ViT VALIDATION FEATURE EXTRACTION")
print("==============================================")


X_val = []
y_val = []


for folder in val_img_dirs:

    if not os.path.isdir(folder):

        print(
            f"WARNING: Folder does not exist:\n{folder}"
        )

        continue

    label = get_label_from_path(folder)

    print(
        f"\nProcessing: "
        f"{os.path.basename(folder)}"
    )

    print(
        f"Label: {label}"
    )

    files = sorted([
        file
        for file in os.listdir(folder)
        if file.lower().endswith(valid_extensions)
    ])

    print(
        f"Images: {len(files)}"
    )

    for i, file in enumerate(
        files,
        start=1
    ):

        image_path = os.path.join(
            folder,
            file
        )

        try:

            emb = get_embedding(
                image_path
            )

            X_val.append(
                emb
            )

            y_val.append(
                label
            )

        except Exception as e:

            print(
                f"ERROR: {image_path}"
            )

            print(e)

        if i % 50 == 0:

            print(
                f"  Processed "
                f"{i}/{len(files)}"
            )


# ============================================================
# 16. CONVERT VALIDATION DATA TO NUMPY
# ============================================================

X_val = np.asarray(
    X_val,
    dtype=np.float32
)

y_val = np.asarray(
    y_val,
    dtype=np.int64
)


print("\n==============================================")
print("ViT VALIDATION FEATURE EXTRACTION COMPLETE")
print("==============================================")

print(
    "X_val shape:",
    X_val.shape
)

print(
    "y_val shape:",
    y_val.shape
)


# ============================================================
# 17. CHECK VALIDATION EMBEDDING DIMENSION
# ============================================================

if len(X_val) > 0:

    print(
        "Validation embedding dimension:",
        X_val.shape[1]
    )

    if X_val.shape[1] != 768:

        raise ValueError(
            f"Expected 768-dimensional "
            f"ViT embeddings, "
            f"but got {X_val.shape[1]}"
        )


# ============================================================
# 18. SAVE EMBEDDINGS
# ============================================================

np.save(
    "vit_X_train.npy",
    X_train
)

np.save(
    "vit_y_train.npy",
    y_train
)

np.save(
    "vit_X_val.npy",
    X_val
)

np.save(
    "vit_y_val.npy",
    y_val
)


print("\nEmbedding files saved:")
print("  vit_X_train.npy")
print("  vit_y_train.npy")
print("  vit_X_val.npy")
print("  vit_y_val.npy")


# ============================================================
# 19. RBF SVM
# ============================================================

print("\n==============================================")
print("TRAINING RBF SVM")
print("==============================================")


svm = Pipeline([

    (
        "scaler",
        StandardScaler()
    ),

    (
        "svm",
        SVC(
            kernel="rbf",
            C=10,
            gamma="scale",
            class_weight="balanced",
            probability=True,
            decision_function_shape="ovr",
            random_state=SEED
        )
    )

])


svm.fit(
    X_train,
    y_train
)


print("\nRBF SVM training completed.")


# ============================================================
# 20. SAVE SVM MODEL
# ============================================================

joblib.dump(
    svm,
    "vit_rbf_svm.joblib"
)

print(
    "Saved model: vit_rbf_svm.joblib"
)


# ============================================================
# 21. GENERATE VALIDATION PREDICTIONS
# ============================================================

print("\n==============================================")
print("GENERATING VALIDATION PREDICTIONS")
print("==============================================")


y_val_pred = svm.predict(
    X_val
)

# IMPORTANT:
# Use predict_proba() rather than decision_function()
# for multiclass AUROC.

y_val_prob = svm.predict_proba(
    X_val
)


print(
    "Validation predictions generated."
)

print(
    "Probability shape:",
    y_val_prob.shape
)

print(
    "First probability vector:",
    y_val_prob[0]
)

print(
    "Probability sum:",
    y_val_prob[0].sum()
)


# ============================================================
# 22. VALIDATION METRICS
# ============================================================

accuracy = accuracy_score(
    y_val,
    y_val_pred
)

balanced_accuracy = balanced_accuracy_score(
    y_val,
    y_val_pred
)

macro_f1 = f1_score(
    y_val,
    y_val_pred,
    average="macro"
)

macro_auroc = roc_auc_score(
    y_val,
    y_val_prob,
    multi_class="ovr",
    average="macro",
    labels=np.arange(NUM_CLASSES)
)


# ============================================================
# 23. CLASSIFICATION REPORT
# ============================================================

classification_report_text = classification_report(
    y_val,
    y_val_pred,
    target_names=CLASS_NAMES,
    digits=4
)


# ============================================================
# 24. PER-CLASS SENSITIVITY / RECALL
# ============================================================

per_class_recall = recall_score(
    y_val,
    y_val_pred,
    average=None,
    labels=np.arange(NUM_CLASSES)
)


print("\n==============================================")
print("ViT + RBF SVM VALIDATION")
print("==============================================")


print(
    f"\nAccuracy:              {accuracy:.4f}"
)

print(
    f"Balanced Accuracy:     {balanced_accuracy:.4f}"
)

print(
    f"Macro-F1:              {macro_f1:.4f}"
)

print(
    f"Macro-AUROC:           {macro_auroc:.4f}"
)


print("\nClassification Report:\n")

print(
    classification_report_text
)


print(
    "\nPer-class sensitivity / recall:"
)

for class_name, recall in zip(
    CLASS_NAMES,
    per_class_recall
):

    print(
        f"{class_name:15s}: "
        f"{recall:.4f}"
    )


# ============================================================
# 25. CONFUSION MATRIX
# ============================================================

cm = confusion_matrix(
    y_val,
    y_val_pred,
    labels=np.arange(NUM_CLASSES)
)


print("\nConfusion Matrix:")

print(cm)


# ============================================================
# 26. NORMALIZED CONFUSION MATRIX
# ============================================================

cm_normalized = (
    cm.astype(float)
    /
    cm.sum(
        axis=1,
        keepdims=True
    )
)


# ============================================================
# 27. BOOTSTRAP FUNCTION
# ============================================================

def bootstrap_metric_ci(
    y_true,
    y_pred,
    y_prob,
    metric_function,
    n_bootstrap=2000,
    seed=42
):

    rng = np.random.default_rng(
        seed
    )

    n = len(y_true)

    scores = []

    for _ in range(
        n_bootstrap
    ):

        indices = rng.integers(
            0,
            n,
            n
        )

        y_true_boot = (
            y_true[indices]
        )

        y_pred_boot = (
            y_pred[indices]
        )

        y_prob_boot = (
            y_prob[indices]
        )

        try:

            score = metric_function(
                y_true_boot,
                y_pred_boot,
                y_prob_boot
            )

            if np.isfinite(score):

                scores.append(
                    score
                )

        except Exception:

            continue


    scores = np.asarray(
        scores
    )


    if len(scores) == 0:

        return (
            np.nan,
            np.nan
        )


    lower = np.percentile(
        scores,
        2.5
    )

    upper = np.percentile(
        scores,
        97.5
    )


    return (
        lower,
        upper
    )


# ============================================================
# 28. BOOTSTRAP METRIC FUNCTIONS
# ============================================================

def metric_accuracy(
    y_true,
    y_pred,
    y_prob
):

    return accuracy_score(
        y_true,
        y_pred
    )


def metric_balanced_accuracy(
    y_true,
    y_pred,
    y_prob
):

    return balanced_accuracy_score(
        y_true,
        y_pred
    )


def metric_macro_f1(
    y_true,
    y_pred,
    y_prob
):

    return f1_score(
        y_true,
        y_pred,
        average="macro"
    )


def metric_macro_auroc(
    y_true,
    y_pred,
    y_prob
):

    return roc_auc_score(
        y_true,
        y_prob,
        multi_class="ovr",
        average="macro",
        labels=np.arange(NUM_CLASSES)
    )


# ============================================================
# 29. RUN BOOTSTRAP
# ============================================================

print("\n==============================================")
print("BOOTSTRAP 95% CONFIDENCE INTERVALS")
print("==============================================")


N_BOOTSTRAP = 2000

print(
    f"\nRunning "
    f"{N_BOOTSTRAP:,} bootstrap iterations..."
)


accuracy_ci = bootstrap_metric_ci(
    y_val,
    y_val_pred,
    y_val_prob,
    metric_accuracy,
    n_bootstrap=N_BOOTSTRAP,
    seed=SEED
)


balanced_accuracy_ci = bootstrap_metric_ci(
    y_val,
    y_val_pred,
    y_val_prob,
    metric_balanced_accuracy,
    n_bootstrap=N_BOOTSTRAP,
    seed=SEED + 1
)


macro_f1_ci = bootstrap_metric_ci(
    y_val,
    y_val_pred,
    y_val_prob,
    metric_macro_f1,
    n_bootstrap=N_BOOTSTRAP,
    seed=SEED + 2
)


macro_auroc_ci = bootstrap_metric_ci(
    y_val,
    y_val_pred,
    y_val_prob,
    metric_macro_auroc,
    n_bootstrap=N_BOOTSTRAP,
    seed=SEED + 3
)


# ============================================================
# 30. PER-CLASS RECALL BOOTSTRAP
# ============================================================

per_class_recall_ci = []


for class_id in range(
    NUM_CLASSES
):

    def class_recall_metric(
        y_true,
        y_pred,
        y_prob,
        class_id=class_id
    ):

        recall_values = recall_score(
            y_true,
            y_pred,
            labels=[class_id],
            average=None,
            zero_division=0
        )

        return recall_values[0]


    ci = bootstrap_metric_ci(
        y_val,
        y_val_pred,
        y_val_prob,
        class_recall_metric,
        n_bootstrap=N_BOOTSTRAP,
        seed=SEED + 10 + class_id
    )

    per_class_recall_ci.append(
        ci
    )


# ============================================================
# 31. PRINT BOOTSTRAP RESULTS
# ============================================================

print(
    f"\nAccuracy: "
    f"{accuracy:.4f} "
    f"(95% CI "
    f"{accuracy_ci[0]:.4f}–"
    f"{accuracy_ci[1]:.4f})"
)


print(
    f"Balanced Accuracy: "
    f"{balanced_accuracy:.4f} "
    f"(95% CI "
    f"{balanced_accuracy_ci[0]:.4f}–"
    f"{balanced_accuracy_ci[1]:.4f})"
)


print(
    f"Macro-F1: "
    f"{macro_f1:.4f} "
    f"(95% CI "
    f"{macro_f1_ci[0]:.4f}–"
    f"{macro_f1_ci[1]:.4f})"
)


print(
    f"Macro-AUROC: "
    f"{macro_auroc:.4f} "
    f"(95% CI "
    f"{macro_auroc_ci[0]:.4f}–"
    f"{macro_auroc_ci[1]:.4f})"
)


print(
    "\nPer-class sensitivity / recall "
    "with 95% CI:"
)


for i, class_name in enumerate(
    CLASS_NAMES
):

    lower, upper = (
        per_class_recall_ci[i]
    )

    print(
        f"{class_name:15s}: "
        f"{per_class_recall[i]:.4f} "
        f"(95% CI "
        f"{lower:.4f}–"
        f"{upper:.4f})"
    )


# ============================================================
# 32. SAVE CONFUSION MATRIX
# ============================================================

plt.figure(
    figsize=(8, 7)
)

plt.imshow(
    cm,
    interpolation="nearest"
)

plt.title(
    "ViT + RBF SVM Confusion Matrix"
)

plt.colorbar()

plt.xticks(
    np.arange(NUM_CLASSES),
    CLASS_NAMES,
    rotation=45,
    ha="right"
)

plt.yticks(
    np.arange(NUM_CLASSES),
    CLASS_NAMES
)

plt.xlabel(
    "Predicted Label"
)

plt.ylabel(
    "True Label"
)


for i in range(
    NUM_CLASSES
):

    for j in range(
        NUM_CLASSES
    ):

        plt.text(
            j,
            i,
            str(cm[i, j]),
            ha="center",
            va="center"
        )


plt.tight_layout()

plt.savefig(
    "vit_svm_confusion_matrix.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# 33. SAVE NORMALIZED CONFUSION MATRIX
# ============================================================

plt.figure(
    figsize=(8, 7)
)

plt.imshow(
    cm_normalized,
    interpolation="nearest"
)

plt.title(
    "ViT + RBF SVM Normalized Confusion Matrix"
)

plt.colorbar()

plt.xticks(
    np.arange(NUM_CLASSES),
    CLASS_NAMES,
    rotation=45,
    ha="right"
)

plt.yticks(
    np.arange(NUM_CLASSES),
    CLASS_NAMES
)

plt.xlabel(
    "Predicted Label"
)

plt.ylabel(
    "True Label"
)


for i in range(
    NUM_CLASSES
):

    for j in range(
        NUM_CLASSES
    ):

        plt.text(
            j,
            i,
            f"{cm_normalized[i, j]:.2f}",
            ha="center",
            va="center"
        )


plt.tight_layout()

plt.savefig(
    "vit_svm_normalized_confusion_matrix.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# 34. MULTICLASS ROC CURVE
# ============================================================

plt.figure(
    figsize=(8, 7)
)


for i, class_name in enumerate(
    CLASS_NAMES
):

    y_true_binary = (
        y_val == i
    ).astype(int)


    fpr, tpr, _ = roc_curve(
        y_true_binary,
        y_val_prob[:, i]
    )


    roc_auc = auc(
        fpr,
        tpr
    )


    plt.plot(
        fpr,
        tpr,
        label=(
            f"{class_name} "
            f"(AUC = {roc_auc:.4f})"
        )
    )


plt.plot(
    [0, 1],
    [0, 1],
    linestyle="--"
)


plt.xlabel(
    "False Positive Rate"
)

plt.ylabel(
    "True Positive Rate"
)

plt.title(
    "ViT + RBF SVM Multiclass ROC Curve"
)

plt.legend(
    loc="lower right"
)

plt.grid(
    True,
    alpha=0.3
)

plt.tight_layout()

plt.savefig(
    "vit_svm_roc_curve.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# 35. SAVE RESULTS TO TEXT FILE
# ============================================================

with open(
    "vit_svm_results.txt",
    "w",
    encoding="utf-8"
) as f:

    f.write(
        "====================================================\n"
    )

    f.write(
        "ViT + RBF SVM VALIDATION RESULTS\n"
    )

    f.write(
        "====================================================\n\n"
    )


    f.write(
        "Feature extractor: Frozen ViT\n"
    )

    f.write(
        f"Model: {MODEL_NAME}\n"
    )

    f.write(
        "Embedding dimension: 768\n"
    )

    f.write(
        "Downstream classifier: RBF SVM\n"
    )

    f.write(
        "Kernel: RBF\n"
    )

    f.write(
        "C: 10\n"
    )

    f.write(
        "Gamma: scale\n"
    )

    f.write(
        "Class weighting: balanced\n"
    )

    f.write(
        "Probability estimates: enabled\n\n"
    )


    f.write(
        f"Training samples: "
        f"{len(y_train)}\n"
    )

    f.write(
        f"Validation samples: "
        f"{len(y_val)}\n\n"
    )


    f.write(
        "----------------------------------------------------\n"
    )

    f.write(
        "MAIN METRICS\n"
    )

    f.write(
        "----------------------------------------------------\n\n"
    )


    f.write(
        f"Accuracy: "
        f"{accuracy:.4f}\n"
    )

    f.write(
        f"Accuracy 95% CI: "
        f"{accuracy_ci[0]:.4f}–"
        f"{accuracy_ci[1]:.4f}\n\n"
    )


    f.write(
        f"Balanced Accuracy: "
        f"{balanced_accuracy:.4f}\n"
    )

    f.write(
        f"Balanced Accuracy 95% CI: "
        f"{balanced_accuracy_ci[0]:.4f}–"
        f"{balanced_accuracy_ci[1]:.4f}\n\n"
    )


    f.write(
        f"Macro-F1: "
        f"{macro_f1:.4f}\n"
    )

    f.write(
        f"Macro-F1 95% CI: "
        f"{macro_f1_ci[0]:.4f}–"
        f"{macro_f1_ci[1]:.4f}\n\n"
    )


    f.write(
        f"Macro-AUROC: "
        f"{macro_auroc:.4f}\n"
    )

    f.write(
        f"Macro-AUROC 95% CI: "
        f"{macro_auroc_ci[0]:.4f}–"
        f"{macro_auroc_ci[1]:.4f}\n\n"
    )


    f.write(
        "----------------------------------------------------\n"
    )

    f.write(
        "PER-CLASS SENSITIVITY / RECALL\n"
    )

    f.write(
        "----------------------------------------------------\n\n"
    )


    for i, class_name in enumerate(
        CLASS_NAMES
    ):

        lower, upper = (
            per_class_recall_ci[i]
        )

        f.write(
            f"{class_name}: "
            f"{per_class_recall[i]:.4f} "
            f"(95% CI "
            f"{lower:.4f}–"
            f"{upper:.4f})\n"
        )


    f.write(
        "\n"
    )


    f.write(
        "----------------------------------------------------\n"
    )

    f.write(
        "CLASSIFICATION REPORT\n"
    )

    f.write(
        "----------------------------------------------------\n\n"
    )

    f.write(
        classification_report_text
    )


    f.write(
        "\n\n"
    )


    f.write(
        "----------------------------------------------------\n"
    )

    f.write(
        "CONFUSION MATRIX\n"
    )

    f.write(
        "----------------------------------------------------\n\n"
    )

    f.write(
        np.array2string(
            cm
        )
    )

    f.write(
        "\n\n"
    )


    f.write(
        "----------------------------------------------------\n"
    )

    f.write(
        "NORMALIZED CONFUSION MATRIX\n"
    )

    f.write(
        "----------------------------------------------------\n\n"
    )

    f.write(
        np.array2string(
            cm_normalized,
            formatter={
                "float_kind":
                lambda x:
                f"{x:.4f}"
            }
        )
    )

    f.write(
        "\n"
    )


# ============================================================
# 36. FINAL OUTPUT SUMMARY
# ============================================================
print("\n==============================================")
print("FILES SAVED")
print("==============================================")

output_files = [
    "vit_X_train.npy",
    "vit_y_train.npy",
    "vit_X_val.npy",
    "vit_y_val.npy",
    "vit_rbf_svm.joblib",
    "vit_svm_results.txt",
    "vit_svm_confusion_matrix.png",
    "vit_svm_normalized_confusion_matrix.png",
    "vit_svm_roc_curve.png"
]

for filename in output_files:

    full_path = os.path.abspath(filename)

    if os.path.exists(full_path):

        size_mb = os.path.getsize(full_path) / (1024 ** 2)

        print(
            f"FOUND: {filename}"
        )

        print(
            f"       {full_path}"
        )

        print(
            f"       Size: {size_mb:.2f} MB"
        )

    else:

        print(
            f"MISSING: {filename}"
        )


print("\n==============================================")
print("ViT + RBF SVM ANALYSIS COMPLETE")
print("==============================================")