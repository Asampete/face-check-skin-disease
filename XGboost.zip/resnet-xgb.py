
import os
import random

import numpy as np
import torch
import matplotlib.pyplot as plt

from PIL import Image

from torchvision.models import (
    resnet50,
    ResNet50_Weights
)

from xgboost import XGBClassifier

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    recall_score,
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    auc
)


# ============================================================
# 2. REPRODUCIBILITY
# ============================================================

SEED = 42

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# ============================================================
# 3. DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("\nUsing device:", device)


# ============================================================
# 4. RESNET-50 MODEL
# ============================================================

print("\n==========================================")
print("LOADING RESNET-50")
print("==========================================")

weights = ResNet50_Weights.IMAGENET1K_V2

model = resnet50(
    weights=weights
)

# Remove ImageNet classification layer.
# ResNet-50 will now output a 2048-dimensional
# feature vector.

model.fc = torch.nn.Identity()

model = model.to(device)

model.eval()

# Official preprocessing for the pretrained weights
transform = weights.transforms()

print("ResNet-50 loaded successfully.")

print(
    "ResNet-50 feature dimension: 2048"
)


# ============================================================
# 5. LABEL MAP
# ============================================================

LABEL_MAP = {
    "Acne": 0,
    "Atopy": 1,
    "Normal": 2,
    "Psoriasis": 3,
    "Rosacea": 4,
    "Seborrheic": 5
}


CLASS_NAMES = [
    "Acne",
    "Atopy",
    "Normal",
    "Psoriasis",
    "Rosacea",
    "Seborrheic"
]


NUM_CLASSES = len(CLASS_NAMES)


# ============================================================
# 6. LABEL FUNCTION
# ============================================================

def get_label_from_path(folder_path):

    folder_name = os.path.basename(
        os.path.normpath(folder_path)
    ).lower()

    if "acne" in folder_name:
        return LABEL_MAP["Acne"]

    elif "atopy" in folder_name:
        return LABEL_MAP["Atopy"]

    elif "normal" in folder_name:
        return LABEL_MAP["Normal"]

    elif "psoriasis" in folder_name:
        return LABEL_MAP["Psoriasis"]

    elif "rosacea" in folder_name:
        return LABEL_MAP["Rosacea"]

    elif "seborrheic" in folder_name:
        return LABEL_MAP["Seborrheic"]

    else:

        raise ValueError(
            f"Could not determine label from folder:\n"
            f"{folder_path}"
        )


# ============================================================
# 7. TRAINING DIRECTORIES
# ============================================================

train_img_dirs = [
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Acne Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Acne side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Atopy Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Normal Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Normal side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Psoriasis Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Rosacea Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Rosacea side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Seborrheic Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Seborrheic side"

]

train_json_dirs = [
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Acne Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Acne side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Atopy Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Normal Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Normal side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Psoriasis Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Rosacea Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Rosacea side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Seborrheic Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\labelling data\TL_Seborrheic side"

]



# 5. IMAGE DIRECTORIES
val_img_dirs = [
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Acne Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Acne side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Atopy Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Normal Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Normal side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Psoriasis Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Rosacea Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Rosacea side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Seborrheic Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Seborrheic side"

]

val_json_dirs = [
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Acne Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Acne side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Atopy Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Normal Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Normal side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Psoriasis Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Rosacea Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Rosacea side",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Seborrheic Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\labelling data\VL_Seborrheic side"

]


# ============================================================
# 9. IMAGE EMBEDDING FUNCTION
# ============================================================

def get_embedding(image_path):

    image = Image.open(
        image_path
    ).convert("RGB")

    image_tensor = transform(
        image
    ).unsqueeze(0)

    image_tensor = image_tensor.to(device)

    with torch.inference_mode():

        embedding = model(
            image_tensor
        )

    embedding = embedding.squeeze(
        0
    ).cpu().numpy()

    return embedding.astype(
        np.float32
    )


# ============================================================
# 10. DATASET EMBEDDING EXTRACTION
# ============================================================

def extract_dataset_embeddings(
    directories,
    dataset_name
):

    X = []
    y = []

    valid_extensions = (
        ".jpg",
        ".jpeg",
        ".png",
        ".bmp"
    )

    print("\n==========================================")
    print(
        f"STARTING {dataset_name.upper()} "
        "RESNET-50 FEATURE EXTRACTION"
    )
    print("==========================================")

    for folder in directories:

        if not os.path.isdir(folder):

            print(
                f"\nWARNING: Folder does not exist:"
            )

            print(folder)

            continue

        label = get_label_from_path(
            folder
        )

        files = [
            file
            for file in os.listdir(folder)
            if file.lower().endswith(
                valid_extensions
            )
        ]

        print(
            f"\nProcessing: "
            f"{os.path.basename(folder)}"
        )

        print(
            f"Label: {label}"
        )

        print(
            f"Images: {len(files)}"
        )

        for i, file in enumerate(
            files,
            start=1
        ):

            image_path = os.path.join(
                folder,
                file
            )

            try:

                embedding = get_embedding(
                    image_path
                )

                X.append(
                    embedding
                )

                y.append(
                    label
                )

            except Exception as e:

                print(
                    f"\nERROR: {image_path}"
                )

                print(e)

            if i % 50 == 0:

                print(
                    f"  Processed "
                    f"{i}/{len(files)}"
                )

    X = np.asarray(
        X,
        dtype=np.float32
    )

    y = np.asarray(
        y,
        dtype=np.int64
    )

    print("\n------------------------------------------")

    print(
        f"{dataset_name} extraction complete"
    )

    print(
        "X shape:",
        X.shape
    )

    print(
        "y shape:",
        y.shape
    )

    return X, y


# ============================================================
# 11. EXTRACT TRAINING FEATURES
# ============================================================

X_train, y_train = extract_dataset_embeddings(
    train_img_dirs,
    "Training"
)


# ============================================================
# 12. EXTRACT VALIDATION FEATURES
# ============================================================

X_val, y_val = extract_dataset_embeddings(
    val_img_dirs,
    "Validation"
)


# ============================================================
# 13. CHECK DATA
# ============================================================

print("\n==========================================")
print("EMBEDDING DIMENSION CHECK")
print("==========================================")

print(
    "Training embedding shape:",
    X_train.shape
)

print(
    "Validation embedding shape:",
    X_val.shape
)

if len(X_train) == 0:

    raise ValueError(
        "No training embeddings were extracted."
    )

if len(X_val) == 0:

    raise ValueError(
        "No validation embeddings were extracted."
    )

print(
    "\nResNet-50 embedding dimension:",
    X_train.shape[1]
)


# ============================================================
# 14. CLASS DISTRIBUTION
# ============================================================

print("\n==========================================")
print("TRAINING CLASS DISTRIBUTION")
print("==========================================")

for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_train == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )


print("\n==========================================")
print("VALIDATION CLASS DISTRIBUTION")
print("==========================================")

for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_val == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )


# ============================================================
# 15. XGBOOST
# ============================================================

print("\n==========================================")
print("TRAINING XGBOOST")
print("==========================================")

xgb = XGBClassifier(

    n_estimators=300,

    max_depth=6,

    learning_rate=0.05,

    subsample=0.8,

    colsample_bytree=0.8,

    objective="multi:softprob",

    num_class=NUM_CLASSES,

    eval_metric="mlogloss",

    random_state=SEED,

    tree_method="hist"
)


xgb.fit(

    X_train,

    y_train,

    eval_set=[
        (X_train, y_train),
        (X_val, y_val)
    ],

    verbose=False
)


print(
    "\nXGBoost training completed."
)



# ============================================================
# 15. XGBOOST LEARNING CURVE
# ============================================================

results = xgb.evals_result()

train_loss = results[
    "validation_0"
]["mlogloss"]

val_loss = results[
    "validation_1"
]["mlogloss"]



train_loss = np.asarray(results["validation_0"]["mlogloss"], dtype=float)
val_loss = np.asarray(results["validation_1"]["mlogloss"], dtype=float)

boosting_rounds = np.arange(1, len(train_loss) + 1)

data = np.column_stack([
    boosting_rounds,
    train_loss,
    val_loss
])


np.savetxt(
    "resnet_xgboost.dat",
    data,
    header="boosting_rounds train_loss val_loss",
    fmt=["%d", "%.8f", "%.8f"]
)