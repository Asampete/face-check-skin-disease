# ============================================================
# SWIN-T + XGBOOST DERMATOLOGY CLASSIFICATION
#
# Synthetic training set
# Synthetic validation set
#
# Swin-T = frozen feature extractor
# XGBoost = downstream classifier
#
# Outputs:
#   Accuracy
#   Balanced Accuracy
#   Macro-F1
#   Per-class sensitivity/recall
#   Macro-AUROC
#   95% bootstrap confidence intervals
#   Confusion matrix
#   Normalized confusion matrix
#   XGBoost training/loss curves
#   ROC curve
#   Saved embeddings
#   Saved XGBoost model
# ============================================================

import os
import random
import numpy as np
import torch
import matplotlib.pyplot as plt

from PIL import Image

from torchvision.models import swin_t, Swin_T_Weights

from xgboost import XGBClassifier

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    recall_score,
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    auc
)

# ============================================================
# 1. REPRODUCIBILITY
# ============================================================

SEED = 42

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# ============================================================
# 2. DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("\nUsing device:", device)


# ============================================================
# 3. SWIN-T MODEL
# ============================================================

print("\nLoading Swin-T...")

weights = Swin_T_Weights.IMAGENET1K_V1

model = swin_t(
    weights=weights
)

# Remove ImageNet classification head
model.head = torch.nn.Identity()

model = model.to(device)

model.eval()

# Official preprocessing associated with the pretrained weights
transform = weights.transforms()

print("Swin-T loaded successfully.")


# ============================================================
# 4. LABEL MAP
# ============================================================

LABEL_MAP = {
    "Acne": 0,
    "Atopy": 1,
    "Normal": 2,
    "Psoriasis": 3,
    "Rosacea": 4,
    "Seborrheic": 5
}

CLASS_NAMES = [
    "Acne",
    "Atopy",
    "Normal",
    "Psoriasis",
    "Rosacea",
    "Seborrheic"
]

NUM_CLASSES = len(CLASS_NAMES)


# ============================================================
# 5. LABEL FUNCTION
# ============================================================

def get_label_from_path(folder_path):

    folder_name = os.path.basename(
        os.path.normpath(folder_path)
    ).lower()

    for disease_name, label in LABEL_MAP.items():

        if disease_name.lower() in folder_name:
            return label

    raise ValueError(
        f"Could not determine label from folder:\n"
        f"{folder_path}"
    )


# ============================================================
# 6. TRAINING DIRECTORIES
# ============================================================

train_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Acne Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Atopy Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Normal Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Psoriasis Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Rosacea Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Seborrheic Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Seborrheic side"
]


# ============================================================
# 7. VALIDATION DIRECTORIES
# ============================================================

val_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Acne Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Atopy Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Normal Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Psoriasis Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Rosacea Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Seborrheic Front",
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Seborrheic side"
]


# ============================================================
# 8. IMAGE EMBEDDING FUNCTION
# ============================================================

def get_embedding(image_path):

    image = Image.open(
        image_path
    ).convert("RGB")

    image_tensor = transform(
        image
    ).unsqueeze(0)

    image_tensor = image_tensor.to(device)

    with torch.inference_mode():

        embedding = model(
            image_tensor
        )

    embedding = embedding.squeeze(
        0
    ).cpu().numpy()

    return embedding.astype(
        np.float32
    )


# ============================================================
# 9. EXTRACT DATASET EMBEDDINGS
# ============================================================

def extract_dataset_embeddings(
    directories,
    dataset_name
):

    X = []
    y = []

    valid_extensions = (
        ".jpg",
        ".jpeg",
        ".png",
        ".bmp"
    )

    print("\n==========================================")
    print(
        f"STARTING {dataset_name.upper()} "
        "SWIN-T FEATURE EXTRACTION"
    )
    print("==========================================")

    for folder in directories:

        if not os.path.isdir(folder):

            print(
                f"\nWARNING: Folder does not exist:\n"
                f"{folder}"
            )

            continue

        label = get_label_from_path(
            folder
        )

        files = [
            file
            for file in os.listdir(folder)
            if file.lower().endswith(
                valid_extensions
            )
        ]

        print(
            f"\nProcessing: "
            f"{os.path.basename(folder)}"
        )

        print(
            f"Label: {label}"
        )

        print(
            f"Images: {len(files)}"
        )

        for i, file in enumerate(
            files,
            start=1
        ):

            image_path = os.path.join(
                folder,
                file
            )

            try:

                embedding = get_embedding(
                    image_path
                )

                X.append(
                    embedding
                )

                y.append(
                    label
                )

            except Exception as e:

                print(
                    f"\nERROR: {image_path}"
                )

                print(e)

            if i % 50 == 0:

                print(
                    f"  Processed "
                    f"{i}/{len(files)}"
                )

    X = np.asarray(
        X,
        dtype=np.float32
    )

    y = np.asarray(
        y,
        dtype=np.int64
    )

    print("\n------------------------------------------")
    print(
        f"{dataset_name} extraction complete"
    )

    print(
        "X shape:",
        X.shape
    )

    print(
        "y shape:",
        y.shape
    )

    return X, y


# ============================================================
# 10. EXTRACT TRAINING FEATURES
# ============================================================

X_train, y_train = extract_dataset_embeddings(
    train_img_dirs,
    "Training"
)


# ============================================================
# 11. EXTRACT VALIDATION FEATURES
# ============================================================

X_val, y_val = extract_dataset_embeddings(
    val_img_dirs,
    "Validation"
)


# ============================================================
# 12. CHECK SWIN-T EMBEDDING DIMENSION
# ============================================================

print("\n==========================================")
print("EMBEDDING DIMENSION CHECK")
print("==========================================")

print(
    "Training embedding shape:",
    X_train.shape
)

print(
    "Validation embedding shape:",
    X_val.shape
)

if len(X_train) == 0:

    raise ValueError(
        "No training embeddings were extracted."
    )

if len(X_val) == 0:

    raise ValueError(
        "No validation embeddings were extracted."
    )

print(
    "Swin-T embedding dimension:",
    X_train.shape[1]
)


# ============================================================
# 13. CLASS DISTRIBUTION
# ============================================================

print("\n==========================================")
print("TRAINING CLASS DISTRIBUTION")
print("==========================================")

for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_train == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )


print("\n==========================================")
print("VALIDATION CLASS DISTRIBUTION")
print("==========================================")

for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_val == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )


# ============================================================
# 14. XGBOOST
# ============================================================

print("\n==========================================")
print("TRAINING XGBOOST")
print("==========================================")

xgb = XGBClassifier(

    n_estimators=300,

    max_depth=6,

    learning_rate=0.05,

    subsample=0.8,

    colsample_bytree=0.8,

    objective="multi:softprob",

    num_class=NUM_CLASSES,

    eval_metric="mlogloss",

    random_state=SEED,

    tree_method="hist"
)


# IMPORTANT:
# eval_set records training and validation loss
# during boosting.

xgb.fit(

    X_train,

    y_train,

    eval_set=[
        (X_train, y_train),
        (X_val, y_val)
    ],

    verbose=False
)


print(
    "\nXGBoost training completed."
)


# ============================================================
# 15. XGBOOST LEARNING CURVE
# ============================================================

results = xgb.evals_result()

train_loss = results[
    "validation_0"
]["mlogloss"]

val_loss = results[
    "validation_1"
]["mlogloss"]



train_loss = np.asarray(results["validation_0"]["mlogloss"], dtype=float)
val_loss = np.asarray(results["validation_1"]["mlogloss"], dtype=float)

boosting_rounds = np.arange(1, len(train_loss) + 1)

data = np.column_stack([
    boosting_rounds,
    train_loss,
    val_loss
])


np.savetxt(
    "swin_xgboost.dat",
    data,
    header="boosting_rounds train_loss val_loss",
    fmt=["%d", "%.8f", "%.8f"]
)