import os
import random
import numpy as np
import torch
import matplotlib.pyplot as plt

from PIL import Image

from torchvision import transforms

from xgboost import XGBClassifier

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    recall_score,
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    auc
)


# ============================================================
# 2. REPRODUCIBILITY
# ============================================================

SEED = 42

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# ============================================================
# 3. DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

dinov2 = torch.hub.load(
    "facebookresearch/dinov2",
    "dinov2_vitb14"
)

dinov2 = dinov2.to(device)

dinov2.eval()

print(
    "\nDINOv2 loaded successfully."
)

# ============================================================
# 5. DINOv2 PREPROCESSING
# ============================================================

transform = transforms.Compose([

    transforms.Resize(
        256,
        interpolation=transforms.InterpolationMode.BICUBIC
    ),

    transforms.CenterCrop(224),

    transforms.ToTensor(),

    transforms.Normalize(
        mean=[
            0.485,
            0.456,
            0.406
        ],
        std=[
            0.229,
            0.224,
            0.225
        ]
    )
])


# ============================================================
# 6. LABEL MAP
# ============================================================

LABEL_MAP = {

    "Acne": 0,

    "Atopy": 1,

    "Normal": 2,

    "Psoriasis": 3,

    "Rosacea": 4,

    "Seborrheic": 5
}


CLASS_NAMES = [

    "Acne",

    "Atopy",

    "Normal",

    "Psoriasis",

    "Rosacea",

    "Seborrheic"
]


NUM_CLASSES = len(
    CLASS_NAMES
)


# ============================================================
# 7. LABEL FUNCTION
# ============================================================

def get_label_from_path(folder_path):

    folder_name = os.path.basename(
        os.path.normpath(folder_path)
    ).lower()

    for disease_name, label in LABEL_MAP.items():

        if disease_name.lower() in folder_name:

            return label

    raise ValueError(
        f"Could not determine label from folder:\n"
        f"{folder_path}"
    )


# ============================================================
# 8. TRAINING DIRECTORIES
# ============================================================

train_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training\raw data\TS_Seborrheic side"
]


# ============================================================
# 9. VALIDATION DIRECTORIES
# ============================================================

val_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation\raw data\VS_Seborrheic side"
]


# ============================================================
# 10. IMAGE EMBEDDING FUNCTION
# ============================================================

def get_embedding(image_path):

    image = Image.open(
        image_path
    ).convert("RGB")

    image_tensor = transform(
        image
    ).unsqueeze(0)

    image_tensor = image_tensor.to(
        device
    )

    with torch.inference_mode():

        embedding = dinov2(
            image_tensor
        )

    embedding = embedding.squeeze(
        0
    ).cpu().numpy()

    return embedding.astype(
        np.float32
    )


# ============================================================
# 11. EXTRACT DATASET EMBEDDINGS
# ============================================================

def extract_dataset_embeddings(
    directories,
    dataset_name
):

    X = []

    y = []

    valid_extensions = (

        ".jpg",

        ".jpeg",

        ".png",

        ".bmp"
    )


    for folder in directories:

        if not os.path.isdir(folder):

            print(
                f"\nWARNING: Folder does not exist:\n"
                f"{folder}"
            )

            continue


        label = get_label_from_path(
            folder
        )


        files = [

            file

            for file in os.listdir(folder)

            if file.lower().endswith(
                valid_extensions
            )
        ]


        print(
            f"\nProcessing: "
            f"{os.path.basename(folder)}"
        )

        print(
            f"Label: {label}"
        )

        print(
            f"Images: {len(files)}"
        )


        for i, file in enumerate(
            files,
            start=1
        ):

            image_path = os.path.join(
                folder,
                file
            )


            try:

                embedding = get_embedding(
                    image_path
                )

                X.append(
                    embedding
                )

                y.append(
                    label
                )


            except Exception as e:

                print(
                    f"\nERROR: {image_path}"
                )

                print(e)


            if i % 50 == 0:

                print(
                    f"  Processed "
                    f"{i}/{len(files)}"
                )


    X = np.asarray(
        X,
        dtype=np.float32
    )


    y = np.asarray(
        y,
        dtype=np.int64
    )


    return X, y


# ============================================================
# 12. EXTRACT TRAINING FEATURES
# ============================================================

X_train, y_train = extract_dataset_embeddings(

    train_img_dirs,

    "Training"
)


# ============================================================
# 13. EXTRACT VALIDATION FEATURES
# ============================================================

X_val, y_val = extract_dataset_embeddings(

    val_img_dirs,

    "Validation"
)


if len(X_train) == 0:

    raise ValueError(
        "No training embeddings were extracted."
    )


if len(X_val) == 0:

    raise ValueError(
        "No validation embeddings were extracted."
    )


print(
    "DINOv2 embedding dimension:",
    X_train.shape[1]
)


for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_train == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )


for class_name, class_id in LABEL_MAP.items():

    count = np.sum(
        y_val == class_id
    )

    print(
        f"{class_name:15s}: {count}"
    )



xgb = XGBClassifier(

    n_estimators=300,

    max_depth=6,

    learning_rate=0.05,

    subsample=0.8,

    colsample_bytree=0.8,

    objective="multi:softprob",

    num_class=NUM_CLASSES,

    eval_metric="mlogloss",

    random_state=SEED,

    tree_method="hist"
)


xgb.fit(

    X_train,

    y_train,

    eval_set=[

        (
            X_train,
            y_train
        ),

        (
            X_val,
            y_val
        )
    ],

    verbose=False
)


# ============================================================
# 17. XGBOOST LEARNING / LOSS CURVE
# ============================================================

results = xgb.evals_result()


train_loss = results[
    "validation_0"
]["mlogloss"]


val_loss = results[
    "validation_1"
]["mlogloss"]


plt.figure(
    figsize=(8, 6)
)


plt.plot(
    train_loss,
    label="Training loss"
)


plt.plot(
    val_loss,
    label="Validation loss"
)


plt.xlabel(
    "Boosting round"
)


plt.ylabel(
    "Multiclass log-loss"
)


plt.title(
    "DINOv2 + XGBoost Learning Curve"
)


plt.legend()


plt.tight_layout()


plt.show()


train_loss = np.asarray(results["validation_0"]["mlogloss"], dtype=float)
val_loss = np.asarray(results["validation_1"]["mlogloss"], dtype=float)

boosting_rounds = np.arange(1, len(train_loss) + 1)

data = np.column_stack([
    boosting_rounds,
    train_loss,
    val_loss
])

np.savetxt(
    "dinov2_xgboost.dat",
    data,
    header="boosting_rounds train_loss val_loss",
    fmt=["%d", "%.8f", "%.8f"]
)