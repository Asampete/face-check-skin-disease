import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_XLA_FLAGS"] = "--tf_xla_auto_jit=0"
os.environ["ABSL_LOG_LEVEL"] = "3"


# ============================================================
# 2. IMPORTS
# ============================================================

import joblib
import numpy as np
import pandas as pd

from PIL import Image
from io import BytesIO

import tensorflow as tf

import matplotlib.pyplot as plt

from xgboost import XGBClassifier

from sklearn.metrics import (
    classification_report,
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    roc_auc_score,
    recall_score,
    confusion_matrix,
    roc_curve,
    auc
)


# ============================================================
# 3. CLASS DEFINITIONS
# ============================================================

LABEL_MAP = {
    "Acne": 0,
    "Atopy": 1,
    "Normal": 2,
    "Psoriasis": 3,
    "Rosacea": 4,
    "Seborrheic": 5
}

CLASS_NAMES = [
    "Acne",
    "Atopy",
    "Normal",
    "Psoriasis",
    "Rosacea",
    "Seborrheic"
]

NUM_CLASSES = 6


# ============================================================
# 4. OUTPUT DIRECTORY
# ============================================================

OUTPUT_DIR = (
    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\derm_foundation_results"
)

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

MODEL_PATH = (
    r"C:\Users\USER\Desktop\Google\derm-foundation"
)

if not os.path.exists(MODEL_PATH):

    raise FileNotFoundError(
        "\nGoogle Derm Foundation model directory "
        "was not found:\n"
        + MODEL_PATH
    )

model = tf.saved_model.load(
    MODEL_PATH
)


if "serving_default" not in model.signatures:

    raise RuntimeError(
        "\nThe SavedModel does not contain "
        "'serving_default'.\n\n"
        "Available signatures:\n"
        + str(list(model.signatures.keys()))
    )

infer = model.signatures[
    "serving_default"
]


train_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Training"
    r"\raw data\TS_Seborrheic side"
]


# ============================================================
# 9. VALIDATION DIRECTORIES
# ============================================================

val_img_dirs = [

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Acne Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Acne side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Atopy Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Atopy side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Normal Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Normal side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Psoriasis Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Psoriasis side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Rosacea Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Rosacea side",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Seborrheic Front",

    r"C:\Users\USER\Downloads\Vit-ML\Vit_Validation"
    r"\raw data\VS_Seborrheic side"
]


for folder in train_img_dirs:

    if not os.path.isdir(folder):

        raise FileNotFoundError(
            "\nTraining directory not found:\n"
            + folder
        )

for folder in val_img_dirs:

    if not os.path.isdir(folder):

        raise FileNotFoundError(
            "\nValidation directory not found:\n"
            + folder
        )



def get_label_from_path(path):

    path_lower = path.lower()

    if "acne" in path_lower:

        return LABEL_MAP["Acne"]

    elif "atopy" in path_lower:

        return LABEL_MAP["Atopy"]

    elif "normal" in path_lower:

        return LABEL_MAP["Normal"]

    elif "psoriasis" in path_lower:

        return LABEL_MAP["Psoriasis"]

    elif "rosacea" in path_lower:

        return LABEL_MAP["Rosacea"]

    elif "seborrheic" in path_lower:

        return LABEL_MAP["Seborrheic"]

    else:

        raise ValueError(
            "\nUnknown class in path:\n"
            + path
        )


# ============================================================
# 12. IMAGE EXTENSIONS
# ============================================================

IMAGE_EXTENSIONS = (
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp"
)


# ============================================================
# 13. GOOGLE DERM FOUNDATION EMBEDDING FUNCTION
# ============================================================

def get_embedding(image_path):

    """
    Convert image to the serialized TensorFlow Example
    format expected by Google Derm Foundation and
    return the embedding vector.
    """

    img = Image.open(
        image_path
    )

    img = img.convert(
        "RGB"
    )

    buffer = BytesIO()

    img.save(
        buffer,
        format="PNG"
    )

    image_bytes = (
        buffer.getvalue()
    )

    example = tf.train.Example(

        features=tf.train.Features(

            feature={

                "image/encoded":
                tf.train.Feature(

                    bytes_list=
                    tf.train.BytesList(

                        value=[
                            image_bytes
                        ]
                    )
                )
            }
        )
    )

    serialized = (
        example.SerializeToString()
    )

    output = infer(
        inputs=tf.constant(
            [serialized]
        )
    )

    if "embedding" not in output:

        raise RuntimeError(
            "\nModel output does not contain "
            "'embedding'.\n\n"
            "Available outputs:\n"
            + str(
                list(output.keys())
            )
        )

    embedding = (
        output["embedding"]
        .numpy()[0]
    )

    return embedding.astype(
        np.float32
    )


X_train = []
y_train = []

train_failed = 0

for folder in train_img_dirs:

    label = get_label_from_path(
        folder
    )

    print(
        f"\nProcessing: {folder}"
    )

    files = sorted(
        os.listdir(folder)
    )

    image_count = 0

    for file in files:

        if not file.lower().endswith(
            IMAGE_EXTENSIONS
        ):

            continue

        image_path = os.path.join(
            folder,
            file
        )

        try:

            embedding = get_embedding(
                image_path
            )

            X_train.append(
                embedding
            )

            y_train.append(
                label
            )

            image_count += 1

        except Exception as e:

            train_failed += 1

            print(
                "\nFAILED:"
            )

            print(
                image_path
            )

            print(
                str(e)
            )


X_val = []
y_val = []

val_failed = 0

for folder in val_img_dirs:

    label = get_label_from_path(
        folder
    )

    print(
        f"\nProcessing: {folder}"
    )

    files = sorted(
        os.listdir(folder)
    )

    image_count = 0

    for file in files:

        if not file.lower().endswith(
            IMAGE_EXTENSIONS
        ):

            continue

        image_path = os.path.join(
            folder,
            file
        )

        try:

            embedding = get_embedding(
                image_path
            )

            X_val.append(
                embedding
            )

            y_val.append(
                label
            )

            image_count += 1

        except Exception as e:

            val_failed += 1

            print(
                "\nFAILED:"
            )

            print(
                image_path
            )

            print(
                str(e)
            )

# ============================================================
# 16. CONVERT TO NUMPY ARRAYS
# ============================================================

X_train = np.asarray(
    X_train,
    dtype=np.float32
)

y_train = np.asarray(
    y_train,
    dtype=np.int64
)

X_val = np.asarray(
    X_val,
    dtype=np.float32
)

y_val = np.asarray(
    y_val,
    dtype=np.int64
)


if len(X_train) == 0:

    raise RuntimeError(
        "No training embeddings were generated."
    )

if len(X_val) == 0:

    raise RuntimeError(
        "No validation embeddings were generated."
    )


xgb = XGBClassifier(

    n_estimators=500,

    max_depth=6,

    learning_rate=0.05,

    objective="multi:softprob",

    num_class=NUM_CLASSES,

    eval_metric="mlogloss",

    random_state=42,

    n_jobs=-1
)


# ============================================================
# 20. TRAIN XGBOOST
# ============================================================

xgb.fit(

    X_train,

    y_train,

    eval_set=[

        (
            X_train,
            y_train
        ),

        (
            X_val,
            y_val
        )
    ],

    verbose=False
)


# ============================================================
# 21. XGBOOST LEARNING CURVE
# ============================================================

results = xgb.evals_result()

train_loss = (
    results["validation_0"]["mlogloss"]
)

val_loss = (
    results["validation_1"]["mlogloss"]
)

plt.figure(
    figsize=(8, 6)
)

plt.plot(
    train_loss,
    label="Training loss"
)

plt.plot(
    val_loss,
    label="Validation loss"
)

plt.xlabel(
    "Boosting round"
)

plt.ylabel(
    "Multiclass log-loss"
)

plt.title(
    "Google Derm Foundation + XGBoost Learning Curve"
)

plt.legend()

plt.tight_layout()

plt.close()

train_loss = np.asarray(results["validation_0"]["mlogloss"], dtype=float)
val_loss = np.asarray(results["validation_1"]["mlogloss"], dtype=float)

boosting_rounds = np.arange(1, len(train_loss) + 1)

data = np.column_stack([
    boosting_rounds,
    train_loss,
    val_loss
])


np.savetxt(
    "google_xgboost.dat",
    data,
    header="boosting_rounds train_loss val_loss",
    fmt=["%d", "%.8f", "%.8f"]
)
